//
//  Slide.swift
//  ParalaxTest
//
//  Created by imacalex on 11/10/17.
//  Copyright © 2017 imacalex. All rights reserved.
//

import Foundation
import UIKit

class Slide: UIView {
    
    var view:UIView!
    var backgroundImage: UIImageView!
    
    var title: UILabel!
    
    var index:Int?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.view = UIView.init(frame: frame)
        self.backgroundImage = UIImageView.init()
        self.title = UILabel.init(frame: CGRect.init(x: 100, y: 200, width: 500, height: 200))
        
        //self.view.addSubview(backgroundImage)
        self.view.addSubview(title)
        setup()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setup()
    }
    
    
    func setup(){
        
        backgroundColor = UIColor.clear
        
        //view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        
        //backgroundImage.frame = bounds
        //backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        backgroundImage.backgroundColor = UIColor.clear
        let img = UIImage.init(named: "BackgroundTree.png")
        let w = (img?.size.width)!
        let h = (img?.size.height)!
        backgroundImage.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        backgroundImage.image = img
        
        addSubview(view)
        
    }
    
    private func loadViewFromNib()->UIView{
        
        let bundle = Bundle(for: type(of:self))
        let nib = UINib(nibName: String.init(describing: type(of:self)), bundle: bundle)
        
        let viewNib = nib.instantiate(withOwner: self, options: nil).first as! UIView
        
        return viewNib
        
    }
    
}
