//
//  ViewController.swift
//  ParalaxTest
//
//  Created by imacalex on 10/10/17.
//  Copyright © 2017 imacalex. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {

    var scrollView : UIScrollView!
    var slidesViews = [Slide]()
    var backgroundImage = UIImageView.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if view.bounds.size.width > view.bounds.size.height{
            print("Landscape")
            view.backgroundColor = UIColor.red
            //let's set the scrollView properties
            self.scrollView = UIScrollView.init(frame: self.view.bounds)
        }else {
            print("Portrait")
            view.backgroundColor = UIColor.gray
            //let's set the scrollView properties
            self.scrollView = UIScrollView.init(frame: self.view.bounds)
        }
        
        let imgB = UIImageView.init(frame: self.view.bounds)
        imgB.image = UIImage.init(named: "foregroundtrees.png")
        self.view.addSubview(imgB)
        
        //Let's load our SlidesInfo
        let info = LoadSlidesPlistFile()
        
        
        //self.scrollView.backgroundColor = UIColor.blue
        self.scrollView.isPagingEnabled = true //This one we can make it false and disable the snapping effect
        
        self.scrollView.bounces = false
        self.scrollView.delegate = self
        
        self.view.addSubview(scrollView)
        
        self.setupSlides(slides: info)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //This way the first slide will begin zooming
        //self.scrollViewDidEndDecelerating(self.scrollView)
        self.zoomingEffect()
    }

    func setupSlides(slides:[SlideInfoModel]){
        //Let's build our slides
        
        for i in 0..<slides.count{
            let slide = Slide(frame: CGRect(origin: CGPoint(), size: UIScreen.main.bounds.size))
            slide.index = i
            slide.frame.origin.x = CGFloat(i) * UIScreen.main.bounds.size.width
            //slide.backgroundImage.image = UIImage.init(named: slides[i].imageName)
            slide.title.text = slides[i].title
            
            self.scrollView.addSubview(slide)
            self.slidesViews.append(slide)
        }
        
        backgroundImage.backgroundColor = UIColor.clear
        let img = UIImage.init(named: "BackgroundTree.png")
        let w = (img?.size.width)!
        let h = (img?.size.height)!
        backgroundImage.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        backgroundImage.image = img
        self.scrollView.addSubview(backgroundImage)
        //Now let's calculate the content width
        let contenWidth = UIScreen.main.bounds.size.width * CGFloat(slides.count)
        
        //Let's set the scrollView ContentSize
        self.scrollView.contentSize = CGSize(width: contenWidth, height: UIScreen.main.bounds.size.height)
    }
    
    //We will be interessted in two delegate methods of UIScrollViewDelegate
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        let currentPage = Int(self.scrollView.contentOffset.x / UIScreen.main.bounds.size.width)
        
        //Let's do the zooming effect
 
    }
    func zoomingEffect(){
        UIView.animate(withDuration: 10.0, delay: 0.1, options: [.curveEaseInOut], animations: {
            
            self.backgroundImage.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
            
        }, completion: nil)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        //Parallax Effect
        let percent = Double(self.scrollView.contentOffset.x / self.scrollView.contentSize.width)
        
        //for i in 0..<self.slidesViews.count{
           // let slide = self.slidesViews[i]
            let offset = Double(backgroundImage.frame.size.width - UIScreen.main.bounds.size.width) / Double(self.slidesViews.count - 1)
            
            let aux = CGFloat(-((percent * offset) + 50))
            backgroundImage.frame.origin.x = aux
            
            
        //}
    }
}




