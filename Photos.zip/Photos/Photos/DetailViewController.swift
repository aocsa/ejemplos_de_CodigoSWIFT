//
//  DetailViewController.swift
//  Photos
//
//  Created by imacalex on 27/10/17.
//  Copyright © 2017 imacalex. All rights reserved.
//

import UIKit
import StoreKit

let DOWNLOAD_TITLE = "Download"
let DOWNLOADED_TITLE = "Downloaded"

class DetailViewController: UIViewController{
    

    @IBOutlet weak var detailDescriptionLabel: UILabel!

    @IBOutlet weak var buyButton: UIButton!    //JL
    
    @IBOutlet weak var btn_pause: UIButton!    //JL
    
    @IBOutlet weak var btn_play: UIButton!    //JL
    
    @IBOutlet weak var btn_cancel: UIButton!    //JL
    
    @IBOutlet weak var progres_bar: UIProgressView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    var transactionObserver: PaymentTransactionObserver!  //JL
    var downloadTaskComic : DownloadTask!  //JL
    
    func configureView() {
        // Update the user interface for the detail item.
        if let product = detailItem {  //JL change detail to product
            if let label = detailDescriptionLabel {
                //label.text = detail.description
                label.text = product.localizedDescription // JL
            }
            // JL
            if let button = self.buyButton {
                configureBuyButton(product: product)
            }
        }
    }
    
    //JL
    @IBAction func pressBuyButton(_ sender: Any) {
        
        ///// TEST ----
        /*transactionObserver.file_to_download = "http://174.138.48.60/Badr/catPhotos.zip"//"http://174.138.48.60/Badr/badrPhotos_sinPass.zip"
        buyButton.setTitle(DOWNLOAD_TITLE, for: .normal)
        activate_resources_to_download(show_: true)*/
        ////------
        
        if buyButton.currentTitle == DOWNLOADED_TITLE{
            print("El archivo ya fue descargado ...")
        }
        if buyButton.currentTitle == DOWNLOAD_TITLE{
            print("download")
            print("mensaje: ", downloadTaskComic.mensaje)
            if downloadTaskComic.mensaje != ""{
                showAlert(title: "Unzipping", message: downloadTaskComic.mensaje)
            }
            if transactionObserver.file_to_download != nil{
                //downloadTaskComic.NAME_FILE_DOWNLOAD = transactionObserver.nameFile
                //downloadTaskComic.PASS_FILE_ZIP = transactionObserver.passFile
                downloadTaskComic.startDownload(url_: transactionObserver.file_to_download, namefile: transactionObserver.nameFile,pasFile: transactionObserver.passFile )
            }
        }else{
            if let product = self.detailItem {
                print("Buying    " + (detailItem?.productIdentifier)! + "...")
                
                transactionObserver.product_id = (detailItem?.productIdentifier)!
                
                let payment = SKPayment(product: product)
                SKPaymentQueue.default().add(payment)
            }
        }
        
    }
    
    func showAlert(title: String, message: String){
        // create the alert
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func pressPause(_ sender: Any) {
        print("pressPause")
        downloadTaskComic.pause()
    }
    
    @IBAction func pressPlay(_ sender: Any) {
        print("pressPlay")
        downloadTaskComic.resume()
    }
    
    @IBAction func pressCancel(_ sender: Any) {
        print("pressCancel")
        downloadTaskComic.cancel()
    }
    //JL
    func updateUIForPurchaseInProgress(inProgress: Bool){
        
        buyButton.isHidden = inProgress
        
        if inProgress {
            activityIndicator.isHidden = false
            activityIndicator.startAnimating()
        } else {
            activityIndicator.stopAnimating()
            activityIndicator.isHidden = true
        }
    }
   //JL
    func activate_resources_to_download(show_: Bool) {
        btn_play.isHidden = !show_
        btn_pause.isHidden = !show_
        btn_cancel.isHidden = !show_
        progres_bar.isHidden = !show_
    }
    //JL
    func signUpForNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(DetailViewController.receivedPurchaseInProgressNotification(notification:)), name: NSNotification.Name(rawValue: IAPTransactionInProgress), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(DetailViewController.receivedPurchaseFailedNotification(notification:)), name: NSNotification.Name(rawValue: IAPTransactionFailed), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(DetailViewController.receivedPurchaseCompletedNotification(notification:)), name: NSNotification.Name(rawValue: IAPTransactionComplete), object: nil)
    }
    
    // JL --- BuyButton
    func configureBuyButton(product: SKProduct) {
        let numberFormatter = NumberFormatter()
        
        numberFormatter.formatterBehavior = .behavior10_4
        numberFormatter.numberStyle = .currency
        numberFormatter.locale = product.priceLocale
        
        let formattedPrice = numberFormatter.string(from: product.price)
        let buttonTitle = String(format: " Buy for %@ ", formattedPrice!)
        
        buyButton.setTitle(buttonTitle, for: .normal)
        
        //JL Style your button
        buyButton.layer.borderWidth = 1.0
        buyButton.layer.cornerRadius = 4.0
        buyButton.layer.borderColor = buyButton.tintColor?.cgColor

    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
        activityIndicator.isHidden = true
        
        //showAlert(title: "hola", message: "sdgfhfshf")
        
        transactionObserver = PaymentTransactionObserver()
        SKPaymentQueue.default().add(transactionObserver)
        
        signUpForNotifications() //JL --- addObserver
        
        activate_resources_to_download(show_: false)
        //progres_bar.setProgress(0.0, animated: false)
        
        downloadTaskComic = DownloadTask(progressBar: progres_bar, btn_: buyButton)
       
    }
    // JL ---- We know that when working with NSNotification we need to have pairs of calls to addObserver and removeObserver.
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    // JL ---
    @objc func receivedPurchaseInProgressNotification(notification: NSNotification) {
        
        updateUIForPurchaseInProgress(inProgress: true)
    }
    //JL ---- FailedNotification
    @objc func receivedPurchaseFailedNotification(notification: NSNotification) {
        
        updateUIForPurchaseInProgress(inProgress: false)
        
        let error = notification.object as! NSError
        
        let alert = UIAlertController(title: "Error", message: error.localizedDescription , preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    //JL -----
    @objc func receivedPurchaseCompletedNotification(notification: NSNotification){
        
        updateUIForPurchaseInProgress(inProgress: false)
        
        //show indicator that download is in progress
        buyButton.setTitle(DOWNLOAD_TITLE, for: .normal)
        activate_resources_to_download(show_: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailItem: SKProduct?/*NSDate?*/ {//JL
        didSet {
            // Update the view.
            configureView()
        }
    }

    
}

