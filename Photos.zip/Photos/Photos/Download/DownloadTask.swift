//
//  DownloadTaskWithNSURLSession
//

import UIKit
#if UseCarthage
    import ZipArchive
#else
    import SSZipArchive
#endif

class DownloadTask: DetailViewController,URLSessionDownloadDelegate {
    var downloadTask: URLSessionDownloadTask!
    var backgroundSession: URLSession!
    
    var NAME_FILE_DOWNLOAD: String = "/file.zip"
    var PASS_FILE_ZIP: String = "catPhotos"
    
    var located_file_download: String!
    
    var progressView: UIProgressView!
    var mensaje:String = ""
    var btn: UIButton!
    
    init(progressBar: UIProgressView, btn_:UIButton) {
        super.init(nibName: nil, bundle: nil)
        let backgroundSessionConfiguration = URLSessionConfiguration.background(withIdentifier: "backgroundSession")
        backgroundSession = Foundation.URLSession(configuration: backgroundSessionConfiguration, delegate: self, delegateQueue: OperationQueue.main)
        
        progressView = progressBar
        progressView.setProgress(0.0, animated: false)
        btn = btn_
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func startDownload(url_: String, namefile: String, pasFile: String) {
        progressView.setProgress(0.0, animated: false)
        self.NAME_FILE_DOWNLOAD = namefile
        self.PASS_FILE_ZIP = pasFile
        let url = URL(string: url_)!
        downloadTask = backgroundSession.downloadTask(with: url)
        downloadTask.resume()
    }
    
    func pause() {
        if downloadTask != nil{
            downloadTask.suspend()
        }
    }
    func resume() {
        if downloadTask != nil{
            downloadTask.resume()
        }
    }
    func cancel() {
        if downloadTask != nil{
            downloadTask.cancel()
        }
    }
    
    func showFileWithPath(path: String){
        let isFileFound:Bool? = FileManager.default.fileExists(atPath: path)
        if isFileFound == true{
            print("showFileWithPath:  " + path)
        }
    }
    
    //MARK: URLSessionDownloadDelegate
    // 1
    func urlSession(_ session: URLSession,
                    downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL){
        
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        let documentDirectoryPath:String = path[0]
        let fileManager = FileManager()
        let aux = NAME_FILE_DOWNLOAD
        let destinationURLForFile = URL(fileURLWithPath: documentDirectoryPath.appendingFormat(aux))
        
        self.located_file_download = destinationURLForFile.path
        if fileManager.fileExists(atPath: destinationURLForFile.path){
            showFileWithPath(path: destinationURLForFile.path)
        }
        else{
            do {
                try fileManager.moveItem(at: location, to: destinationURLForFile)
                // show file
                showFileWithPath(path: destinationURLForFile.path)
                
               
                
            }catch{
                print("An error occurred while moving file to destination url")
            }
        }
    }
    
    // 2
    func urlSession(_ session: URLSession,
                    downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64){
        //progressView.setProgress(Float(totalBytesWritten)/Float(totalBytesExpectedToWrite), animated: true)
        print(Float(totalBytesWritten)/Float(totalBytesExpectedToWrite))
        progressView.setProgress(Float(totalBytesWritten)/Float(totalBytesExpectedToWrite), animated: true)
    }
    
    //MARK: URLSessionTaskDelegate
    func urlSession(_ session: URLSession,
                    task: URLSessionTask,
                    didCompleteWithError error: Error?){
        downloadTask = nil
        //progressView.setProgress(0.0, animated: true)
        if (error != nil) {
            print(error!.localizedDescription)
        }else{
            print("The task finished transferring data successfully")
            print("unzip")
            unzipPressed()
        }
    }
    
    /// ----------------------------- UNZIP ------------------------------
    func unzipPressed() {
        guard let zipPath = self.located_file_download else {
            return
        }
        
        guard let unzipPath = tempUnzipPath() else {
            return
        }
        
        let password = PASS_FILE_ZIP
        let success: Bool = SSZipArchive.unzipFile(atPath: zipPath,
                                                   toDestination: unzipPath,
                                                   preserveAttributes: true,
                                                   overwrite: true,
                                                   nestedZipLevel: 1,
                                                   password: password.isEmpty == false ? password : nil,
                                                   error: nil,
                                                   delegate: nil,
                                                   progressHandler: nil,
                                                   completionHandler: nil)
        if success != false {
            print("Success unzip")
            deleteFile(url_: zipPath)
        } else {
            print("No success unzip")
            return
        }
        
        var items: [String]
        do {
            items = try FileManager.default.contentsOfDirectory(atPath: unzipPath)
        } catch {
            return
        }
        
        for (index, item) in items.enumerated() {
            print("item: " + item)
            mensaje += item + " , "
        }
        //mensaje += "\n " + unzipPath
        print("mensaje en DownloadTask: " , mensaje)
        //showAlert(title: "Unzipping", message: mensaje)
        btn.setTitle(mensaje, for: .normal)
    }
    
    func tempUnzipPath() -> String? {
        var path = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true)[0]
        path += "/\(UUID().uuidString)"
        let url = URL(fileURLWithPath: path)
        
        do {
            try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: nil)
        } catch {
            return nil
        }
        return url.path
    }
    
    
    func deleteFile(url_: String) {
        // Create a FileManager instance
        
        let fileManager = FileManager.default
        
        // Delete 'hello.swift' file
        
        do {
            try fileManager.removeItem(atPath: url_)
            print("Success delete File!")
        }
        catch let error as NSError {
            print("Ooops! Something went wrong deleteFile: \(error)")
        }
    }
}
