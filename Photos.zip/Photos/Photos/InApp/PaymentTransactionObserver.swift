//
//  PaymentTransactionObserver.swift
//  Photos
//
//  Created by imacalex on 27/10/17.
//  Copyright © 2017 imacalex. All rights reserved.
//

import Foundation
import StoreKit

let IAPTransactionInProgress = "IAPTransactionInProgress"
let IAPTransactionFailed = "IAPTransactionFailed"
let IAPTransactionComplete = "IAPTransactionComplete"

// JL
class PaymentTransactionObserver: NSObject,SKPaymentTransactionObserver {
    
    var product_id : String!
    
    var file_to_download:String!
    var nameFile: String!
    var passFile: String!
    
    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        for transaction in transactions {
            
            if let trans = transaction as? SKPaymentTransaction {
                switch (trans.transactionState) {
                case .purchasing:
                    showTransactionAsInProgress(deferred: false)
                case .deferred:
                    showTransactionAsInProgress(deferred: true)
                case .failed:
                    failedTransaction(transaction: trans)
                case .purchased:
                    completeTransaction(queue: queue,transaction: trans)
                case .restored:
                    restoreTransaction(transaction: trans)
                }
            }
        }
    }
    
    func showTransactionAsInProgress(deferred: Bool) {
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: IAPTransactionInProgress), object: deferred)
        print("in progress ok ...")
    }
    
    func failedTransaction(transaction: SKPaymentTransaction) {
        NotificationCenter.default.post(name:  NSNotification.Name(rawValue: IAPTransactionFailed), object: transaction.error)
        file_to_download = ""
        SKPaymentQueue.default().finishTransaction(transaction)
    }
    
    func completeTransaction(queue: SKPaymentQueue,transaction: SKPaymentTransaction) {
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: IAPTransactionComplete), object: transaction)
        
        //will add code to start downloading photos
        if (product_id != nil){
            print("buy ok ..." + (product_id))
            if (product_id) == "com.nwes.Photos.BadrPhotos"{
                nameFile = "/badrPhotos_sinPass.zip"
                file_to_download = "http://174.138.48.60/Badr" + nameFile
                passFile = ""
            }
            if (product_id) == "com.nwes.Photos.CatPhotos"{
                nameFile = "/catPhotos.zip"
                file_to_download = "http://174.138.48.60/Badr" + nameFile
                passFile = "catPhotos"
            }
            if (product_id) == "com.nwes.Photos.DogPhotos"{
                nameFile = "/dogPhotos.zip"
                file_to_download = "http://174.138.48.60/Badr" + nameFile
                passFile = "dogPhotos"
            }
            
            SKPaymentQueue.default().finishTransaction(transaction)
            SKPaymentQueue.default().remove(self) //It's necesary if you do more that one buy
        }else{
            print("buy not ok ...")
        }
    }
    
    func restoreTransaction(transaction: SKPaymentTransaction) {
        print("restored ok ...")
        if (product_id != nil){
            print((product_id))
            
        }
        
        SKPaymentQueue.default().finishTransaction(transaction)
    }
    
    
}

