//
//  IAPHelper.swift
//  Photos
//
//  Created by imacalex on 27/10/17.
//  Copyright © 2017 imacalex. All rights reserved.
//

import Foundation
import UIKit
import StoreKit

// -------------- CREATE ---IAPHelper---------------
class IAPHelper: NSObject,SKProductsRequestDelegate {
    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        print("product count \(response.products.count)")
        print("invalid product IDs \(response.invalidProductIdentifiers)")
        
        if response.products.count > 0 {
            var products: [SKProduct] = []
            for prod in response.products {
                if prod.isKind(of: SKProduct.self) {
                    products.append(prod as SKProduct)
                }
            }
            completionHandler(true, products)
        }
    }
    
    let productIdentifiers: NSSet
    override init() {
        productIdentifiers = NSSet(objects: "com.nwes.Photos.BadrPhotos", "com.nwes.Photos.CatPhotos", "com.nwes.Photos.DogPhotos")
    }
    var completionHandler: ((Bool, [SKProduct]?) -> Void)!
    
    func requestProductsWithCompletionHandler(completionHandler_:@escaping (Bool, [SKProduct]?) -> Void){
        self.completionHandler = completionHandler_
        
        let productsRequest = SKProductsRequest(productIdentifiers: productIdentifiers as! Set<String>)
        productsRequest.delegate = self
        productsRequest.start()
    }
    func request(request: SKRequest!, didFailWithError error: NSError!) {
        
        completionHandler(false, nil)
    }
}
//------------------FIN -IAPHelper------------
