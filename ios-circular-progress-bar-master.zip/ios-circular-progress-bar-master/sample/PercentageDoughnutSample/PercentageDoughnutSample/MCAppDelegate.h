//
//  MCAppDelegate.h
//  PercentageDoughnutSample
//
//  Created by Vinícius Rodrigues on 6/05/2014.
//  Copyright (c) 2014 MyAppControls. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
