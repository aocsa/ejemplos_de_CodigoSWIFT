//
//  UITransitionBaseView.m
//  iXbox
//
//  Created by Omar Mozo on 6/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UITransitionBaseView.h"
/**
 This class is an Abstract Class where <b>animation:</b> must be redefined.
 */
@implementation UITransitionBaseView
/**
 This constructor set the image array.
 */
- (id) initWithFrame:(CGRect) frame ImageArray:(NSArray *)images
{
    self = [super initWithFrame:frame];
    if (self) {
        imageArray = images.copy; 
        posImage = 0;
        timeInterval = 5.0;
    }
    return self;
}
/**
 This method start the animation that will be on <b>animation:</b> function
 */
- (void)start{
    timer = [NSTimer scheduledTimerWithTimeInterval:timeInterval target:self selector:@selector(animation:) userInfo:nil repeats:YES];
}
/**
 stop the animation cycle
 */
- (void) stop{
    [timer invalidate];
    timer = nil;
}
/**
 this function needs implementation, know it just call at nextImage method.
 */
- (void)animation:(id)sender{
    [self nextImage];
}
/**
 change the position of the image in the array, if it is the last, return al first, to work as circular list.
 */
- (void) nextImage{
    if (posImage>=imageArray.count-1)  posImage = 0; 
    else posImage ++;
}

- (void)reDraw{
    if (posImage == 0) {
        posImage = imageArray.count - 1;
    } else {
        posImage--;
    }
    [self animation:nil];
}

@end
