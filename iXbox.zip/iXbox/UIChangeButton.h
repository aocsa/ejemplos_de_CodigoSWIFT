//
//  UIChangeButton.h
//  iXbox
//
//  Created by Omar Mozo on 9/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIChangeButton : UIButton{    
    /**
     image view that will be show at view
     */
    UIImageView *imageView;
    /**
     title that will be show at view
     */
    UILabel *titleLabel;
    /**
     number that will be show at view
     */
    UILabel *numberLabel;
}
/**
 Constructor that inicialize the image and title
 */
- (id) initWithFrame:(CGRect) frame Image:(UIImage *) image Title:(NSString *)title;
/**
 change de value of the number of this button
 */
- (void) changeNumberValue:(int) number;
/**
 here the image number and title are relocated
 */
- (void)reDraw;
@end
