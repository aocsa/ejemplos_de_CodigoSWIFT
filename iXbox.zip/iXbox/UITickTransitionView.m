//
//  UITickTransitionView.m
//  iXbox
//
//  Created by Omar Mozo on 6/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UITickTransitionView.h"

@implementation UITickTransitionView

/**
 This is the constructor redefined, where the tickerView object is created and added to this view
 and for default the animation id down.
 */
- (id) initWithFrame:(CGRect)frame ImageArray:(NSArray *)images{
    self = [super initWithFrame:frame ImageArray:images];
    if (self) {
        tickerView = [[SBTickerView alloc] initWithFrame:self.bounds];
        
        /*if (posImage == 3) {
            [tickerView setFrontView:[[UIImageView alloc] initWithImage:[UITransitionOpacityView imageByScalingAndCroppingForSize:self.frame.size Image:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] principalPoint:self.center]]];
        } else {*/
            [tickerView setFrontView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] ]];
        //}
        
        /*[tickerView setFrontView:[[UIImageView alloc] initWithImage:[UITransitionOpacityView imageByScalingAndCroppingForSize:self.frame.size Image:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] principalPoint:self.center]]];*/
        //[self nextImage];
        [self addSubview:tickerView];
        up = 0;
    }
    return self;
}
/**
 this method says the way how the animations should work Upd or Down.
 */
- (void) isAnimationUp:(BOOL)isUp{
    up = isUp?1:0;
}
/**
 Perform the animation, changing the backimage and say that it should change.
 */
- (void)animation:(id)sender{
    [super animation:sender];
    
    /*if (posImage == 2) {
        [tickerView setBackView:[[UIImageView alloc] initWithImage:[UITransitionOpacityView imageByScalingAndCroppingForSize:self.frame.size Image:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] principalPoint:self.center]]];
    } else {*/
        [tickerView setBackView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] ]];
    //}
    
    
    [tickerView tick:up animated:YES completion:nil];
    
}

- (void) setFrame:(CGRect)frame{
    [super setFrame:frame];
    tickerView.frame = self.bounds;
}
@end
