//
//  UIComicCarousel.h
//  iXbox
//
//  Created by Yuber on 1/27/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIBaseView.h"
#import "iCarousel.h"
#import "UIChangeButton.h"

@interface UIComicCarousel : UIBaseView<iCarouselDataSource, iCarouselDelegate,UIScrollViewDelegate>{
    NSArray *items;
    iCarousel *carousel;
    BOOL wrap;    
    
    UIView *fakeAllImage;
    
    UIImageView *fakeImage;
    UIScrollView *fakeScroll;
    UIImageView *fakeButton;
    
    CGSize fakeScrollSize;
    
    UIScrollView *avatarVertical;
    
    NSMutableArray *buttonList;
    UILabel *titleLayer;
}
- (id) initWithImages:(NSArray *)images Title:(NSString *)title;
- (void) addButton: (UIChangeButton *)button;
@end
