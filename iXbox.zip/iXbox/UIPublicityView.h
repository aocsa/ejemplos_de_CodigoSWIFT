//
//  UIPublicityView.h
//  iXbox
//
//  Created by Omar Mozo on 10/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIBaseView.h"
#import "UIBaseView.h"
#import "XboxScrollView.h"
#import "UITransitionOpacityView.h"
#import <MediaPlayer/MediaPlayer.h>

@interface UIPublicityView : UIBaseView{    
    UITransitionOpacityView *transitionView;
    UITransitionOpacityView *transitionMediaView;   
    UIImageView *backgroundImage;
    int imagePos;
}
@property(nonatomic) int imagePos;

- (id) initWithImages:(UITransitionOpacityView *)images Videos:(UITransitionOpacityView *)videos;
@end
