//
//  UITransitionBaseView.h
//  iXbox
//
//  Created by Omar Mozo on 6/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITransitionBaseView : UIView{
    /**
     the set of image that will be change in a period of time
     */
    NSArray *imageArray;
    /**
     the image that will be show
     */
    int posImage;
    /**NSTimer for delete the animation*/
    NSTimer *timer;
    /**
     Time interval for each animation
     */
    CGFloat timeInterval;
}
- (id) initWithFrame:(CGRect) frame ImageArray:(NSArray *)images;
- (void)start;
- (void) stop;
- (void)animation:(id)sender;
- (void) nextImage;

- (void)reDraw;
@end
