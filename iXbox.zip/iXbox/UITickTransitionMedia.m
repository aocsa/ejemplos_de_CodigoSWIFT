//
//  UITickTransitionMedia.m
//  iXbox
//
//  Created by Omar Mozo on 11/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UITickTransitionMedia.h"

@implementation UITickTransitionMedia
/**
 This is the constructor redefined, where the tickerView object is created and added to this view
 and for default the animation id down.
 */
- (id) initWithFrame:(CGRect)frame ImageArray:(NSArray *)images{
    self = [super initWithFrame:frame ImageArray:images];
    if (self) {
        timeInterval = 5.0;
        tickerView = [[SBTickerView alloc] initWithFrame:self.bounds];       
        NSURL *url = [[NSURL alloc] initFileURLWithPath: [[NSBundle mainBundle] pathForResource:[imageArray objectAtIndex:posImage] ofType:@"mp4"]];
        moviePlayer1 = [[MPMoviePlayerController alloc] initWithContentURL:url];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayBackReadyPlay:)
                                                     name:MPMoviePlayerPlaybackStateDidChangeNotification
                                                   object:moviePlayer1];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayBackDidFinish:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:moviePlayer1];

        
        
        
        
        [moviePlayer1 prepareToPlay];
        moviePlayer1.controlStyle = MPMovieControlStyleNone;
        
        
        
        moviePlayer1.shouldAutoplay = NO;
        
        [tickerView setFrontView:moviePlayer1.view];
        [self nextImage];
        [self addSubview:tickerView];
        up = 0;
        
        
        
    }
    return self;
}
/**
 this method says the way how the animations should work Upd or Down.
 */
- (void) isAnimationUp:(BOOL)isUp{
    up = isUp?1:0;
}
/**
 Perform the animation, changing the backimage and say that it should change.
 */
- (void)animation:(id)sender{
    NSURL *url = [[NSURL alloc] initFileURLWithPath: [[NSBundle mainBundle] pathForResource:[imageArray objectAtIndex:posImage] ofType:@"mp4"]];
    
    moviePlayer2 = [[MPMoviePlayerController alloc] initWithContentURL:url];
    
    // moviePlayer2.controlStyle = MPMovieControlStyleNone;
    //moviePlayer2.movieControlMode = MPMovieControlModeHidden;
    moviePlayer2.controlStyle = MPMovieControlStyleNone;
    

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackReadyPlay:)
                                                 name:MPMoviePlayerPlaybackStateDidChangeNotification
                                               object:moviePlayer2];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:moviePlayer2];
  
    moviePlayer2.shouldAutoplay = NO;
    
    
    [moviePlayer2 prepareToPlay];
    [tickerView setBackView:moviePlayer2.view];
    [tickerView tick:up animated:YES completion:nil];
    [super animation:sender];
}

- (void) moviePlayBackDidFinish:(NSNotification*)notification {
    
    //MPMoviePlayerController *moviePlayer = [notification object];    
    //[moviePlayer stop];
    [self start];   
}

- (void) moviePlayBackReadyPlay:(NSNotification*)notification {
    
    //MPMoviePlayerController *moviePlayer = [notification object];    
    //[moviePlayer play];
    [self stop];   
}

@end
