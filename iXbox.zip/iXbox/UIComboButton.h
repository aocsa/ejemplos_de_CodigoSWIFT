//
//  UIComboButton.h
//  iXbox
//
//  Created by Yuber on 1/25/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/message.h>

@interface UIComboButton : UIView{
    UIButton *buttonSelection;
    UIScrollView *optionScroll;
    NSArray *optionArray;
    NSMutableArray *optionButtonArray;
    BOOL _orientation;
    CGRect originalFrame;
    BOOL firstTime;
    
    BOOL selectionOpen;
    
    id target;
    SEL action;
    
    UIImageView *comboMore;
}

@property (nonatomic,strong) NSArray *optionArray;

//- (id)initWithFrame:(CGRect)frame Options:(NSArray *)options orientation:(BOOL) orientation;
- (id)initWithDefaultOptionName:(NSString *)defaultName;
- (void) setTarget:(id)aTarget action:(SEL)anAction;
@end
