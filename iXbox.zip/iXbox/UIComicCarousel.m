//
//  UIComicCarousel.m
//  iXbox
//
//  Created by Yuber on 1/27/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIComicCarousel.h"

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)

#define NUMBER_OF_ITEMS 16
#define NUMBER_OF_VISIBLE_ITEMS 16
#define ITEM_SPACING 210
#define INCLUDE_PLACEHOLDERS YES

@implementation UIComicCarousel

- (id) initWithImages:(NSArray *)images Title:(NSString *)title{
    self = [super initWithAttributes:nil];
    if (self) {
        carousel = [[iCarousel alloc] init]; 
        carousel.type = iCarouselTypeRotary;
        carousel.delegate = self;
        carousel.dataSource = self;
        [self addSubview:carousel];
        //NSMutableArray *ma = [NSMutableArray array];
        avatarVertical = [[UIScrollView alloc] initWithFrame:CGRectMake(170, 200, 300, 400)];
        avatarVertical.pagingEnabled = YES;
        //avatarVertical.clipsToBounds = NO;
        
        //avatarVertical.backgroundColor = [UIColor redColor];
        
        items = images.copy;
        
        CGFloat yPos = 0;
        NSString *str;
        for ( int i =0; i<items.count ;i++) {
            //[ma addObject:str];
            str = [images objectAtIndex:i];
            UIImageView *imgV = [[UIImageView alloc] initWithImage:[UIImage imageNamed:str]];
            //imgV.backgroundColor = [UIColor redColor];
            //imgV.frame = CGRectMake(0, yPos, imgV.frame.size.width, imgV.frame.size.height);
            
            imgV.frame = CGRectMake(0, yPos, avatarVertical.frame.size.width, avatarVertical.frame.size.height);
            
            yPos += avatarVertical.frame.size.height;
            [avatarVertical addSubview:imgV];
            
            //[ma addObject:@""];
        }
        avatarVertical.contentSize = CGSizeMake(avatarVertical.frame.size.width, avatarVertical.frame.size.height*images.count);
        
        avatarVertical.delegate = self;
        [self addSubview:avatarVertical];
        
        
        
        fakeAllImage = [[UIView alloc] init];
        
        UIImage *img;
        
        
        fakeImage = [[UIImageView alloc] init];
        img = [UIImage imageNamed:@"coment0.png"];
        fakeImage.frame=CGRectMake(10, 10, img.size.width, img.size.height);
        fakeImage.image = img;
        [fakeAllImage addSubview:fakeImage];
        
        fakeScroll = [[UIScrollView alloc] init];
        img = [UIImage imageNamed:@"coment1.png"];
        fakeScroll.frame = CGRectMake(10, 218-50, 307, 400+50);
        
        
        
        fakeScrollSize = img.size;
        [fakeScroll addSubview:[[UIImageView alloc] initWithImage:img]];
        [fakeAllImage addSubview:fakeScroll];
        
        fakeButton = [[UIImageView alloc] init];
        img = [UIImage imageNamed:@"coment2.png"];
        fakeButton.frame=CGRectMake(10, fakeScroll.frame.size.height+fakeScroll.frame.origin.y, img.size.width, img.size.height);
        fakeButton.image = img;
        [fakeAllImage addSubview:fakeButton];
        
        fakeAllImage.frame = CGRectMake(0, 0, fakeImage.frame.size.width, fakeImage.frame.size.height+fakeScroll.frame.size.height+fakeButton.frame.size.height);
        
        [self addSubview:fakeAllImage];
        
        wrap = YES;
        
        buttonList = [NSMutableArray array];
        
        titleLayer = [[UILabel alloc] init];
        titleLayer.text = title; 
        titleLayer.textColor = [UIColor grayColor];
        titleLayer.backgroundColor = [UIColor clearColor];
        [self addSubview:titleLayer];
        
    }
    return self;
}

- (void) reDraw{
    [super reDraw];
    titleLayer.frame = CGRectMake(self.frame.size.width/8, self.frame.size.height/20, self.frame.size.width*6/8, self.frame.size.height/20);
    
    titleLayer.font = [UIFont fontWithName:[[self getFontTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] size:[[[self getFontSizeTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] intValue]];
    
    if ([UIBaseView orientation] == 0) {
        carousel.alpha = 0;
        avatarVertical.alpha = 1;
        [avatarVertical scrollRectToVisible:CGRectMake(0, avatarVertical.frame.size.height*[carousel currentItemIndex], avatarVertical.frame.size.width, avatarVertical.frame.size.height) animated:YES];
    }else{
        avatarVertical.alpha = 0;
        carousel.frame = CGRectMake(0, 100, self.frame.size.width-200, self.frame.size.height-200);
        carousel.alpha = 1;
        
        float numPage = avatarVertical.contentOffset.y /avatarVertical.frame.size.height;
        
        [carousel scrollToItemAtIndex:numPage animated:YES];
    }
    
    
    
    fakeAllImage.frame = CGRectMake(self.frame.size.width-fakeAllImage.frame.size.width-20, 100, fakeAllImage.frame.size.width, fakeAllImage.frame.size.height);
    
    if ([UIBaseView orientation] == 0) {
        fakeScroll.frame =CGRectMake(10, 218-50, 307, 400+50);
        fakeScroll.contentSize = fakeScrollSize;
    }else{
        //[self bringSubviewToFront:fakeScroll];
        fakeScroll.frame = CGRectMake(10, 218-50, 307, 180+50);
        fakeScroll.contentSize = fakeScrollSize;        
    }
    fakeButton.frame=CGRectMake(10, fakeScroll.frame.size.height+fakeScroll.frame.origin.y, fakeButton.frame.size.width, fakeButton.frame.size.height);
    
    
    UIButton *button;
    CGFloat buttonPos = self.frame.size.height/4.827911857;
    for (int k = 0; k<buttonList.count; k++) {
        button = [buttonList objectAtIndex:k];
        button.frame = CGRectMake(30, buttonPos, button.frame.size.width,  button.frame.size.height);
        buttonPos = buttonPos + button.frame.size.height +20;
        //button.backgroundColor = [UIColor greenColor];
        //[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //button.titleLabel.font = [UIFont fontWithName:@"Arial" size:[[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone?6:14];
        
    }
    
}

- (void) addButton: (UIChangeButton *)button{
    [self addSubview:button];
    [buttonList addObject:button];
}

#pragma mark -
#pragma mark iCarousel methods

- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return [items count];
}

- (NSUInteger)numberOfVisibleItemsInCarousel:(iCarousel *)carousel
{
    //limit the number of items views loaded concurrently (for performance reasons)
    return NUMBER_OF_VISIBLE_ITEMS;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index
{
    //create a numbered view
	UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 500, 500)];
    
    
    //Image:[UIImage imageNamed:[items objectAtIndex:index]]
    //view.backgroundColor = [UIColor redColor];  
    UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[items objectAtIndex:index]]];
    img.frame = CGRectMake(0, 0, 200, 300);
    img.center = view.center;
    [view addSubview:img];
    //view.frame = CGRectMake(0, 0, 500, 300);
	/*UILabel *label = [[UILabel alloc] initWithFrame:view.bounds];
	label.text = [[items objectAtIndex:index] stringValue];
	label.backgroundColor = [UIColor clearColor];
	label.textAlignment = UITextAlignmentCenter;
	label.font = [label.font fontWithSize:50];
	[view addSubview:label];*/
	return view;
}


- (CGFloat)carouselItemWidth:(iCarousel *)carousel
{
    //slightly wider than item view
    return ITEM_SPACING;
}

- (CATransform3D)carousel:(iCarousel *)_carousel transformForItemView:(UIView *)view withOffset:(CGFloat)offset
{
    //implement 'flip3D' style carousel
    
    //set opacity based on distance from camera
    view.alpha = 1.0 - fminf(fmaxf(offset, 0.0), 1.0);
    
    //do 3d transform
    CATransform3D transform = CATransform3DIdentity;
    transform.m34 = carousel.perspective;
    transform = CATransform3DRotate(transform, M_PI / 8.0, 0, 1.0, 0);
    return CATransform3DTranslate(transform, 0.0, 0.0, offset * carousel.itemWidth);
}

- (BOOL)carouselShouldWrap:(iCarousel *)carousel
{
    //wrap all carousels
    return wrap;
}

- (void)carouselDidEndScrollingAnimation:(iCarousel *)carouselTmp{
       
    for (int k=0;k<items.count;k++) {
        [carousel itemViewAtIndex:k].transform = CGAffineTransformIdentity;    

    }
    
    fakeImage.transform = CGAffineTransformMakeScale(0.25, 0.25);
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    fakeImage.transform = CGAffineTransformIdentity;
    [carousel currentItemView].transform = CGAffineTransformMakeScale(1.25, 1.25);
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];
    
    //[avatarVertical scrollRectToVisible:CGRectMake(0, avatarVertical.frame.size.height*[carousel currentItemIndex], avatarVertical.frame.size.width, avatarVertical.frame.size.height) animated:YES];
    
}

#pragma mark
#pragma mark UIScrollViewDelegate methods

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    //float numPage = avatarVertical.contentOffset.y /avatarVertical.frame.size.height; ///avatarVertical.frame.size.height;
    //[carousel scrollToItemAtIndex:numPage animated:YES];
    
    }

@end
