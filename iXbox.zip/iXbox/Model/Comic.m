//
//  Comic.m
//  iXbox
//
//  Created by Omar Mozo on 26/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "Comic.h"
@implementation Comic
@synthesize title,authors,volumes,image;

- (id)init {
    self = [super init];
    if (self) {
        
        self.title = @"The Leyend of the INKAS";
        self.authors = [NSArray arrayWithObjects:@"aaaaa", nil];
        self.image = @"";
        
        /*Volume *v0 = [[Volume alloc] init];
        v0.title = @"The Beginning";
        v0.volume = @"Volume I";
        v0.description = @"was the largest empire in pre-Columbian America. The administrative, political and military center of the empire was located in Cusco in modern-day Peru. The Inca civilization arose from the highlands of Peru sometime in the early 13th century. From 1438 to 1533, the Incas used a variety of methods, from conquest to peaceful assimilation, to incorporate a large portion of western South America, centered on the Andean mountain ranges, including, besides Peru, large parts of modern Ecuador, western and south central Bolivia, northwest Argentina, north and north-central Chile, and southern Colombia into a state comparable to the historical empires of Eurasia.";
        v0.image = @"volume1.jpg";
        
        Volume *v1 = [[Volume alloc] init];
        v1.title = @"The Story ";
        v1.volume = @"Volume II";
        v1.description = @"The Inca referred to their empire as Tawantinsuyu, \"four parts together.\" In Quechua the term Tawantin is a group of four things (tawa \"four\" with the suffix -ntin which names a group). Suyu means \"region\" or \"province\". The empire was divided into four suyus, whose corners met at the capital, Cusco (Qosqo). The name Tawantinsuyu was, therefore, a descriptive term indicating a union of provinces. The Spanish transliterated the name as Tahuatinsuyo or Tahuatinsuyu which is often still used today.";
        v1.image = @"volume2.jpg";
        
        self.volumes = [NSArray arrayWithObjects:v0,v1, nil];*/
    }
    return self;
}

- (Volume *) getVolumeByIdentifier: (int)identifier{
    return [self.volumes objectAtIndex:identifier];
}

@end

@implementation Volume
@synthesize title,description,volume,image;

- (id) initWithImage:(NSString *)imageName{
    self = [super init];
    if (self) {
        image = imageName;
    }
    return self;
}

- (id)copyWithZone:(NSZone *)zone{
    Volume *copy = [[[self class] allocWithZone: zone] init];
    
    copy->title = nil;
    [copy setTitle:[self title]];
    
    copy->image = nil;
    [copy setImage:[self image]];
    
    return copy;
}

@end

