//
//  Comic.h
//  iXbox
//
//  Created by Omar Mozo on 26/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Volume : NSObject <NSCopying>{
    NSString *title;
    NSString *volume;
    NSString *description;
    NSString *image;
}
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *volume;
@property (nonatomic,strong) NSString *description;
@property (nonatomic,strong) NSString *image;

- (id) initWithImage: (NSString *)imageName;
@end

@interface Comic : NSObject{
    NSString *title;
    NSArray *authors;
    NSArray *volumes;
    NSString *image;
}
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSArray *authors;
@property (nonatomic,strong) NSArray *volumes;
@property (nonatomic,strong) NSString *image;

- (Volume *) getVolumeByIdentifier: (int)identifier;

@end



