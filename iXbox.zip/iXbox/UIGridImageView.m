//
//  UIGridImageView.m
//  iXbox
//
//  Created by Omar Mozo on 12/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIGridImageView.h"
@interface UIGridImageView()
- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize Image:(UIImage *)image principalPoint:(CGPoint)point;
- (void) addFrameTemplateListAttribute;
- (void) setFrameTemplateAttribute:(NSArray *)frameTemplate;
- (NSArray *) getFrameTemplateAttribute;
@end

@implementation UIGridImageView
- (id) initWithImages:(NSArray *)images PrincipalPoints:(NSArray *)points{
    self = [super initWithAttributes:nil];
    if (self) {
        [self addFrameTemplateListAttribute];
        
        if (points == nil) {
            NSMutableArray *pointArr = [NSMutableArray array];
            for (int i=0;i<images.count;i++) {
                [pointArr addObject:NSStringFromCGPoint(CGPointMake(0, 0))];
            }
            points = [NSArray arrayWithArray:pointArr];
        }
        
        if (imageArray.count == points.count) @throw [NSException exceptionWithName:@"ImagesPointsNotFitException" reason:@"the array of images and points have not the same number of items" userInfo:nil];
        
        NSMutableArray *imagesArr = [NSMutableArray array];
        NSMutableArray *imageViewArr = [NSMutableArray array];
        
        if (images.count == 5) {
            int k =0;
            for (NSArray *imgName in images) {
                UITransitionBaseView *v;
                [imagesArr addObject: imgName];//[UIImage imageNamed:imgName]];
                if (k!=0 && k!= 4) {
                    v= [[UITransitionOpacityView alloc] initWithFrame:CGRectZero ImageArray:imgName /*[NSArray arrayWithObjects:imgName,@"img_1.png",nil]*/];
                    
                } else {
                    v= [[UITickTransitionView alloc] initWithFrame:CGRectZero ImageArray:imgName /*[NSArray arrayWithObjects:imgName,@"img_1.png",nil]*/];                   
                }
                [v start];
                //v = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imgName]];
                [imageViewArr addObject:v];
                [self addSubview:v];
                k++;
            }
        } else {
            for (NSString *imgName in images) {
                [imagesArr addObject: imgName];//[UIImage imageNamed:imgName]];
                UIView *v = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imgName]];
                [imageViewArr addObject:v];
                [self addSubview:v];
            }
        }        
        imageArray = [NSArray arrayWithArray:imagesArr];
        imageViewArray = [NSArray arrayWithArray:imageViewArr];
        principalPointArray = points;
        
        
        self.userInteractionEnabled = YES;
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
        [tapGesture setDelegate:self];
        [self addGestureRecognizer:tapGesture];
    }
    return self;
}

-(void) handleTapGesture:(UITapGestureRecognizer *)gestureRecognizer{
    objc_msgSend(target, action,nil);
}

- (void) reDraw{
    [super reDraw];
    /*for (UIView *view in self.subviews) {
        [view removeFromSuperview];
    }*/
        
    CGRect rect;
    for (int i=0;i<imageArray.count;i++) {
        //rect =
        rect = CGRectFromString([[[self getFrameTemplateAttribute] objectAtIndex:imageArray.count-1] objectAtIndex:i+([UIBaseView orientation]*imageArray.count)]);
        //CGSize imgSize = CGSizeMake(self.frame.size.width*rect.size.width, self.frame.size.height*rect.size.height);
        CGRect imgRect = CGRectMake(self.frame.size.width*rect.origin.x, self.frame.size.height*rect.origin.y,self.frame.size.width*rect.size.width, self.frame.size.height*rect.size.height);
        
        
        
        if (imageArray.count == 5) {
            UITransitionBaseView *imgView = [imageViewArray objectAtIndex:i];
            imgView.frame = imgRect;    
            [imgView reDraw];
        }else{
            UIImageView *imgView;
            imgView = [imageViewArray objectAtIndex:i];
            imgView.image = [self imageByScalingAndCroppingForSize:imgRect.size Image:[UIImage imageNamed:[imageArray objectAtIndex:i]] principalPoint:CGPointFromString([principalPointArray objectAtIndex:i])]; 
            imgView.frame = imgRect;
        }
        
           
        
        
    }
}

- (NSArray *) getSizeOfImages{
    return nil;
}
- (void) setTails:(NSArray *)tails{
    
}


- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize Image:(UIImage *)image principalPoint:(CGPoint)point
{
    UIImage *sourceImage = image;
    UIImage *newImage = nil;        
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointZero;
    CGPoint principalPoint = CGPointMake(point.x/width, point.y/width);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO) 
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor) 
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * principalPoint.y; 
        }
        else 
            if (widthFactor < heightFactor)
            {
                thumbnailPoint.x = (targetWidth - scaledWidth) * principalPoint.x;
            }
    }       
    
    UIGraphicsBeginImageContext(targetSize); // this will crop
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil) 
        NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}
- (void) addFrameTemplateListAttribute{
    NSArray *oneElemente = [NSArray arrayWithObjects:@"{{0,0},{1,1}}",@"{{0,0},{1,1}}", nil];
    NSArray *twoElemente = [NSArray arrayWithObjects:@"{{0.0000,0.0000},{1.0000,0.6333}}",@"{{0.0000,0.6833},{1.0000,0.3167}}",@"{{0.0000,0.0000},{0.6333,1.0000}}",@"{{0.6833,0.0000},{0.3167,1.0000}}", nil];
    NSArray *threeElemente = [NSArray arrayWithObjects:@"{{0.0000,0.0000},{1.0000,0.7125}}",@"{{0.0000,0.7625},{0.4750,0.2375}}",@"{{0.5250,0.7625},{0.4750,0.2375}}",@"{{0.0000,0.0000},{0.2250,1.0000}}",@"{{0.2750,0.0000},{0.4500,1.0000}}",@"{{0.7750,0.0000},{0.2250,1.0000}}", nil];
    NSArray *fourElemente = [NSArray arrayWithObjects:@"{{0.0000,0.0000},{0.4750,0.6333}}",@"{{0.5250,0.0000},{0.4750,0.3008}}",@"{{0.5250,0.3483},{0.4750,0.1429}}",@"{{0.0000,0.6833},{1.0000,0.3167}}",@"{{0.0000,0.0000},{0.2250,0.6333}}",@"{{0.2750,0.0000},{0.4500,0.6333}}",@"{{0.7750,0.0000},{0.2250,0.6333}}",@"{{0.0000,0.6833},{1.0000,0.3167}}", nil];
    NSArray *fiveElemente = [NSArray arrayWithObjects:@"{{0.0000,0.0000},{1.0000,0.3943}}",@"{{0.0000,0.4085},{0.4942,0.1958}}",@"{{0.0000,0.8170},{1.0000,0.1972}}",@"{{0.0000,0.6071},{0.4942,0.1958}}",@"{{0.5058,0.4085},{0.4942,0.3943}}",@"{{0.0000,0.0000},{0.6589,0.6619}}",@"{{0.0000,0.6690},{0.3257,0.3310}}",@"{{0.3333,0.6690},{0.3257,0.3310}}",@"{{0.6705,0.0000},{0.3295,0.3310}}",@"{{0.6705,0.3381},{0.3295,0.6619}}", nil];
    //NSArray *sixElemente = [NSArray arrayWithObjects:@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"", nil];
    
    NSArray *frameTemplate = [NSArray arrayWithObjects:oneElemente,twoElemente,threeElemente, fourElemente,fiveElemente,/*sixElemente,*/nil];
    
    [self setFrameTemplateAttribute:frameTemplate];
}

- (void) setFrameTemplateAttribute:(NSArray *)frameTemplate{    
    [attributes setObject:frameTemplate forKey:@"frameTemplate"];
}

- (NSArray *) getFrameTemplateAttribute{
    return [attributes objectForKey:@"frameTemplate"];
}

- (void) setTarget:(id)aTarget action:(SEL)anAction{
    target = aTarget;
    action = anAction;
}
@end
