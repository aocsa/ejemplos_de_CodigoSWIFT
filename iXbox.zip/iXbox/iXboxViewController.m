//
//  iXboxViewController.m
//  iXbox
//
//  Created by Omar Mozo on 20/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "iXboxViewController.h"
#import "XboxScrollView.h"
#import "XboxBackView.h"
#import "UIComicCollection.h"
#import "UIComicCollectionVertical.h"
#import "UIComicCollectionHorizontal.h"
#import "UIComicItem.h"
#import "Comic.h"
#import "UIGridView.h"
#import "UITransitionOpacityView.h"
#import "UITickTransitionView.h"

@implementation iXboxViewController
@synthesize store = _store;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    [super loadView];
    //self.view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 768, 1024)];
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    /*NSArray *names = [UIFont familyNames];
	NSArray *fontFaces;
	NSLog(@"Font FamilyNames");
	for (NSString *name in names) {
		NSLog(@"Font Family:  %@",name);
		fontFaces = [UIFont fontNamesForFamilyName:name];
		for (NSString *fname in fontFaces) {
			NSLog(@"              %@",fname);
		}
	}*/
    
    scroll = [[XboxScrollView alloc] init];
        
    [scroll setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [scroll setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"", @"layer2_p.png",@"layer2.png", nil]];
    [scroll setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [scroll setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    [scroll setTitleSelectedColorAttribute:[NSArray arrayWithObjects:@"{{0,0},{0,0}}",@"{{0,0},{0,0}}", @"{{0,0},{0,1}}",@"{{0,0},{0,1}}", nil]];
    [scroll setTitleUnselectedColorAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    [scroll reDraw];
    
    //----------------------------------------------------------------
    UIGridView *v1 = [[UIGridView alloc] initWithTitle:@"recent news"]; 
    [v1 setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-UltraLight",@"HelveticaNeue-UltraLight", nil]];
    [v1 setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"42",@"42", nil]];
    
    
    UIView *vb = [[UIView alloc] init];
    
    UITransitionOpacityView *vb0 = [[UITransitionOpacityView alloc] initWithFrame:CGRectMake(0, 0, 196, 147) ImageArray:[NSArray arrayWithObjects:@"condor.png",@"condor2.png", @"elvalle.png",@"maca.png", nil]];
    [vb addSubview:vb0];
    
    UIButton *whyButtonMagStore = [UIButton buttonWithType:UIButtonTypeCustom];
    [whyButtonMagStore addTarget:self action:@selector(showTurismSoreView:) forControlEvents:UIControlEventTouchUpInside];
    whyButtonMagStore.frame = CGRectMake(0,0, 196, 147);
    [vb0 addSubview:whyButtonMagStore];
    
    

//    [vb addGestureRecognizer:tapGestureToMagazineStore];
    [vb0 start];
    
    UITickTransitionView *vb1 = [[UITickTransitionView alloc] initWithFrame:CGRectMake(0,150, 196, 147) ImageArray:[NSArray arrayWithObjects:@"ayarbanner1.png",@"ayarbanner2.png",@"ayarbanner3.png",@"ayarbanner4.png",nil]];
    
    UIButton *whyButtonAyarStore = [UIButton buttonWithType:UIButtonTypeCustom];
    [whyButtonAyarStore addTarget:self action:@selector(handleMyComics:) forControlEvents:UIControlEventTouchUpInside];
    whyButtonAyarStore.frame = CGRectMake(0,0, 196, 147);
    [vb1 addSubview:whyButtonAyarStore];
    
    //[myComicsButton addTarget:self action:@selector(handleMyComics:) forControlEvents:UIControlEventTouchUpInside];

    
    [vb addSubview:vb1];
    [vb1 start];
    
    vb.frame = CGRectMake(0, 0, 196, 344);
    
    UIView *vg = [[UIView alloc] init];
    
    UITickTransitionMedia2 *vg1 = [[UITickTransitionMedia2 alloc] initWithFrame:CGRectMake(0,0, 397, 298) ImageArray:[NSArray arrayWithObjects:@"vive_esp",@"catalogo_esp", nil]];
    
    [vg addSubview:vg1];
    [vg1 start];
    
    vg.frame = CGRectMake(0, 0, 397, 300);
    
    UIView *vr = [[UIView alloc] init];      
    vr.frame = CGRectMake(0, 0, 196, 300);
    UIButton *whyButton1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [whyButton1 addTarget:self action:@selector(showPublicity2ScreenView:) forControlEvents:UIControlEventTouchUpInside];
    whyButton1.frame = CGRectMake(0,0, 196, 147);
    UITransitionOpacityView *vr0 = [[UITransitionOpacityView alloc] initWithFrame:CGRectMake(0, 0, 196, 147) ImageArray:[NSArray arrayWithObjects:@"banner1.png",@"banner2.png",@"banner3.png",@"banner4.png",nil]];
    [vr0 addSubview:whyButton1];
    [vr0 start];
    [vr addSubview:vr0];
     
    publicityView2 = [[XboxBackView alloc] initWithBackView:scroll Title:@"advertisement" Flecha:@"flecha_blanca.png"];
    [publicityView2 setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [publicityView2.contentView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];    
    [publicityView2 setFontColorTitleAttribute:[NSArray arrayWithObjects:@"{{255,255},{320,460}}",@"{{0,0},{480,300}}", @"{{255,255},{255,1}}",@"{{255,255},{255,1}}", nil]];
    [publicityView2 setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [publicityView2 setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    [publicityView2 setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"",@"uicomic-home-promperu-related-portrait.png",@"uicomic-home-promperu-related.png", nil]];
    
    
    XboxScrollView *publicityScroll2 = [[XboxScrollView alloc] init];    
    [publicityScroll2 setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    publicityScroll2.labelHeight = 170;
    [publicityScroll2 setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue",@"", @"HelveticaNeue",@"HelveticaNeue", nil]];
    [publicityScroll2 setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"24",@"24", nil]];
    [publicityScroll2 setTitleSelectedColorAttribute:[NSArray arrayWithObjects:@"{{0,0},{0,0}}",@"{{0,0},{0,0}}", @"{{255,255},{255,1}}",@"{{255,255},{255,1}}", nil]];
    [publicityScroll2 setTitleUnselectedColorAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    
    
    
   
    //UIFakeView *pv2 = [[UIFakeView alloc] init];  
    UIBaseView *pv2 = [[UIBaseView alloc] init];  
    
    [publicityScroll2 addSubview:pv2 Title:@"peru"];
    
    [publicityView2 addContent:publicityScroll2];
    
    publicityView2.alpha = 0;
    [self.view addSubview:publicityView2];
    [publicityView2 reDraw];
    [publicityScroll2 refresh];
        
    
    vr.userInteractionEnabled = YES;
    UIButton *whyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [whyButton addTarget:self action:@selector(showPublicityScreenView:) forControlEvents:UIControlEventTouchUpInside];
    whyButton.frame = CGRectMake(0,0, 196, 147);  
    UITickTransitionView *vr1 = [[UITickTransitionView alloc] initWithFrame:CGRectMake(0, 150, 196, 147) ImageArray:[NSArray arrayWithObjects:@"banner6.png",@"banner7.png",@"banner8.png",@"banner5.png",nil]];    
    [vr1 start];
    [vr1 addSubview:whyButton];
    [vr addSubview:vr1];    
    
    
    publicityView = [[XboxBackView alloc] initWithBackView:scroll Title:@"advertisement" Flecha:@"flecha_blanca.png"];
    [publicityView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [publicityView.contentView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [publicityView setFontColorTitleAttribute:[NSArray arrayWithObjects:@"{{255,255},{320,460}}",@"{{0,0},{480,300}}", @"{{255,255},{255,1}}",@"{{255,255},{255,1}}", nil]];
    [publicityView setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [publicityView setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    
    XboxScrollView *publicityScroll = [[XboxScrollView alloc] init];    
    [publicityScroll setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    publicityScroll.labelHeight = 170;
    [publicityScroll setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue",@"", @"HelveticaNeue",@"HelveticaNeue", nil]];
    [publicityScroll setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"24",@"24", nil]];
    [publicityScroll setTitleSelectedColorAttribute:[NSArray arrayWithObjects:@"{{0,0},{0,0}}",@"{{0,0},{0,0}}", @"{{255,255},{255,1}}",@"{{255,255},{255,1}}", nil]];
    [publicityScroll setTitleUnselectedColorAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    
    
    UIPublicityView *publicityViewContent = [[UIPublicityView alloc] initWithImages:[[UITransitionOpacityView alloc] initWithFrame:CGRectMake(0, 0, 768, 576) ImageArray:[NSArray arrayWithObjects:@"7402_thumb.jpg",@"7406_thumb.jpg",@"7407_thumb.jpg",@"7408_thumb.jpg",@"7413_thumb.jpg",@"chanchanwp_thumb.jpg",@"limawp_thumb.jpg",@"mapiwp_thumb.jpg", nil]] Videos:[[UITransitionOpacityView alloc] initWithFrame:CGRectMake(0, 0, 196, 147) ImageArray:[NSArray arrayWithObjects:@"layer12.png",@"layer13.png",@"layer22.png",@"layer3.png", nil]]];
    
    [publicityViewContent setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"",[NSArray arrayWithObjects:@"layer2_v.png", @"",@"",nil],[NSArray arrayWithObjects:@"layer2_h.png", @"",@"",nil], nil]];
    [publicityViewContent setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [publicityScroll addSubview:publicityViewContent Title:@"about"];
    [publicityView addContent:publicityScroll];
    
    publicityView.alpha = 0;
    [self.view addSubview:publicityView];
    [publicityView reDraw];
    [publicityScroll refresh];
    
    vb.frame = CGRectMake(0, 0, 196, 300);
    [v1 setSubViews:[NSArray arrayWithObjects:vb,vg,vr, nil]];
    
    UIChangeButton *cb1 = [[UIChangeButton alloc] initWithFrame:CGRectMake(0, 0, 124, 74) Image:[UIImage imageNamed:@"layer7.png"] Title:@"about"];
    cb1.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"layer4.png"]];
    [cb1 changeNumberValue:7];
    [cb1 addTarget:self action:@selector(showGeneralAboutView:) forControlEvents:UIControlEventTouchUpInside];
    [v1 addButton:cb1];
    
    UIChangeButton *cb2 = [[UIChangeButton alloc] initWithFrame:CGRectMake(0, 0, 124, 74) Image:[UIImage imageNamed:@"layer27.png"] Title:@"share"];
    cb2.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"layer4.png"]];
    [cb2 changeNumberValue:5];
    [cb2 addTarget:self action:@selector(twitterTap:) forControlEvents:UIControlEventTouchUpInside];
    [v1 addButton:cb2];
    
    [scroll addSubview:v1 Title:@"home"];
    UIComicCollectionVertical *v2 = [[UIComicCollectionVertical alloc] initWithTitle:@"content"];  
    [v2 setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-UltraLight",@"HelveticaNeue-UltraLight", nil]];
    [v2 setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"42",@"42", nil]];

    
    UIChangeButton *turismStoreButton = [[UIChangeButton alloc] initWithFrame:CGRectMake(0, 0, 124, 74) Image:[UIImage imageNamed:@"layer27.png"] Title:@"tourism store"];
    turismStoreButton.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"layer4.png"]];
    [turismStoreButton addTarget:self action:@selector(showTurismSoreView:) forControlEvents:UIControlEventTouchUpInside];    
    [turismStoreButton changeNumberValue:5];
    [v2 addButton:turismStoreButton];
    
    
    UIChangeButton *myComicsButton = [[UIChangeButton alloc] initWithFrame:CGRectMake(0, 0, 124, 74) Image:[UIImage imageNamed:@"layer7.png"] Title:@"comic store"];
    myComicsButton.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"layer4.png"]];
    [myComicsButton changeNumberValue:7];
    [myComicsButton addTarget:self action:@selector(handleMyComics:) forControlEvents:UIControlEventTouchUpInside];
    [v2 addButton:myComicsButton];
    
    
    comicListView = [[XboxBackView alloc] initWithBackView: scroll Title:@"ayar: the inka's legend" Flecha:@"flecha.png"];  
    [comicListView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [comicListView setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"", @"layer2_p.png",@"layer2.png", nil]];
    [comicListView setFontColorTitleAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    [comicListView setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [comicListView setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    comicListView.alpha = 0;
    
    UIComicCollectionHorizontal *comicCollection = [[UIComicCollectionHorizontal alloc] initWithTitle:@""];
    [comicCollection setFrameAttribute:[comicListView getContentBounds]];
    /*Comic *comic = [[Comic alloc] init];
    Volume *vol0 = [[Volume alloc] init];    
    vol0.image = @"vol0.png";
    
    Volume *vol1 = [[Volume alloc] init];    
    vol1.image = @"vol1.png";
    
    Volume *vol2 = [[Volume alloc] init];    
    vol2.image = @"vol2.png";
    
    Volume *vol3 = [[Volume alloc] init];    
    vol3.image = @"vol3.png";
    
    Volume *vol4 = [[Volume alloc] init];    
    vol4.image = @"vol4.png";
    
    Volume *vol5 = [[Volume alloc] init];    
    vol5.image = @"vol5.png";
    
    Volume *vol6 = [[Volume alloc] init];    
    vol6.image = @"vol6.png";    
    
    comic.volumes = [NSArray arrayWithObjects:vol0,vol1,vol2,vol3,vol4,vol5,vol6, nil];
    
    
    UIComicItem *it0 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:0];
    [comicCollection addComicResume:it0];
    
    UIComicItem *it1 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:1];
    [comicCollection addComicResume:it1];
    
    UIComicItem *it2 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:2];
    [comicCollection addComicResume:it2];
    
    UIComicItem *it3 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:3];
    [comicCollection addComicResume:it3];
    
    UIComicItem *it4 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:4];
    [comicCollection addComicResume:it4];
    
    UIComicItem *it5 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:5];
    [comicCollection addComicResume:it5];
    
    UIComicItem *it6 = [[UIComicItem alloc] initWithManagedObjectContext:comic ComicId:6];
    [comicCollection addComicResume:it6];*/
    [comicCollection setStore:_store];
    
    [comicListView addContent:comicCollection];
    [comicListView reDraw];
    [self.view addSubview:comicListView];
    
    NSArray *imgs = [NSArray arrayWithObjects:
                     [NSArray arrayWithObjects:@"img_1.png",@"img_2_1.png", nil],
                     [NSArray arrayWithObjects:@"img_2.png",@"img_2_2.png", nil],
                     [NSArray arrayWithObjects:@"img_3.png",@"img_2_4.png", nil],
                     [NSArray arrayWithObjects:@"img_4.png",@"img_2_3.png", nil], 
                     [NSArray arrayWithObjects:@"img_5.png",@"img_2_5.png", nil], 
                     nil];
    
    NSArray *points = [NSArray arrayWithObjects:@"{157,107}",@"{81,47}",@"{0,156}",@"{181,62}",@"{126,132}", nil];
    
    UIGridImageView *v2_grid = [[UIGridImageView alloc] initWithImages:imgs PrincipalPoints:points];
    [v2_grid setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{162,129},{460,704}}",@"{{171,146},{693,437}}", nil]];
    [v2_grid setTarget:self action:@selector(handleMyComics:)];
        
    NSArray *imgs2 = [NSArray arrayWithObjects:
                      [NSArray arrayWithObjects:@"img_3_1.png",@"img_4_1.png", nil],
                      [NSArray arrayWithObjects:@"img_3_2.png",@"img_4_2.png", nil],
                      [NSArray arrayWithObjects:@"img_3_3.png",@"img_4_3.png", nil],
                      [NSArray arrayWithObjects:@"img_3_4.png",@"img_4_4.png", nil], 
                      [NSArray arrayWithObjects:@"img_3_5.png",@"img_4_5.png", nil], 
                      nil];
    NSArray *points2 = [NSArray arrayWithObjects:@"{157,107}",@"{81,47}",@"{0,156}",@"{181,62}",@"{126,132}", nil];
    
    UIGridImageView *v2_grid2 = [[UIGridImageView alloc] initWithImages:imgs2 PrincipalPoints:points2];
    [v2_grid2 setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{162,129},{460,704}}",@"{{171,146},{693,437}}", nil]];    
    [v2_grid2 setTarget:self action:@selector(showTurismSoreView:)];
    [v2 addComicResume:v2_grid2];
    [v2 addComicResume:v2_grid];
    

    
    [scroll addSubview:v2 Title:@"store"];
    
    UIComicCarousel *v3 = [[UIComicCarousel alloc] initWithImages:[NSArray arrayWithObjects:@"avatar_1.png",@"avatar_2.png",@"avatar_3.png",@"avatar_5.png",@"avatar_1.png",@"avatar_2.png",@"avatar_3.png",@"avatar_5.png", nil] Title:@"infographics"];
    
    [v3 setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-UltraLight",@"HelveticaNeue-UltraLight", nil]];
    [v3 setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"42",@"42", nil]];
    UIChangeButton *cb132 = [[UIChangeButton alloc] initWithFrame:CGRectMake(0, 0, 124, 74) Image:[UIImage imageNamed:@"layer7.png"] Title:@"about"];
    cb132.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"layer4.png"]];
    [cb132 changeNumberValue:7];
    [cb132 addTarget:self action:@selector(showAboutView:) forControlEvents:UIControlEventTouchUpInside];
    [v3 addButton:cb132];
    
    
    UIChangeButton *cb23 = [[UIChangeButton alloc] initWithFrame:CGRectMake(0, 0, 124, 74) Image:[UIImage imageNamed:@"layer27.png"] Title:@"share"];
    cb23.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"layer4.png"]];
    [cb23 changeNumberValue:5];
    [cb23 addTarget:self action:@selector(twitterTap:) forControlEvents:UIControlEventTouchUpInside];
    [v3 addButton:cb23];
    
    [scroll addSubview:v3 Title:@"more"];
    
    UIButton *twitterButton = [UIButton buttonWithType:UIButtonTypeCustom] ;
    UIImageView* twitterImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"layer11.png"]];
    [twitterImage setFrame:CGRectMake(0, 0, 11, 16)];
    [twitterButton addSubview:twitterImage];    
    [twitterButton addTarget:self action:@selector(twitterTap:) forControlEvents:UIControlEventTouchUpInside];
    [twitterButton sizeToFit];
    [twitterButton setFrame:twitterImage.frame];
    [scroll addIcon:twitterButton];
    [scroll refresh];
    
    
    UIButton *facebookButton = [UIButton buttonWithType:UIButtonTypeCustom] ;
    UIImageView* facebookImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"layer10.png"]];
    [facebookImage setFrame:CGRectMake(0, 0, 19, 17)];
    [facebookButton addSubview:facebookImage];    
    [facebookButton sizeToFit];
    [facebookButton setFrame:facebookImage.frame];
    [scroll addIcon:facebookButton];
    
    UIButton *mailButton = [UIButton buttonWithType:UIButtonTypeCustom] ;
    UIImageView* mailImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"layer9.png"]];
    [mailImage setFrame:CGRectMake(0, 0, 18, 13)];
    [mailButton addSubview:mailImage];    
    [mailButton sizeToFit];
    [mailButton setFrame:mailImage.frame];
    [scroll addIcon:mailButton];
    
    backview = [[XboxBackView alloc] initWithBackView: scroll Title:@"Test" Flecha:@"backArrow_black@2x.png"];    
    [backview setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    
    backview.alpha = 0;
     
    [scroll reDraw];
    [backview reDraw];
    
    [self.view addSubview:backview]; 
    [self.view addSubview:scroll];
    
    aboutView = [[XboxBackView alloc] initWithBackView:scroll Title:@"about: the ayar comic" Flecha:@"flecha.png"];
    [aboutView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    //[aboutView.contentView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];    
    [aboutView setFontColorTitleAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    [aboutView setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [aboutView setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    [aboutView setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"",@"about-v.psd.png",@"about-h.psd.png", nil]];
    
    aboutView.alpha = 0;
    
    [aboutView reDraw];
    
    [self.view addSubview:aboutView];
    
    
    [self.view addSubview:twitterButton];
    [self.view addSubview:facebookButton];
    [self.view addSubview:mailButton];
    
    generalAboutView = [[XboxBackView alloc] initWithBackView: scroll Title:@"about: inka's press" Flecha:@"flecha.png"];  
    [generalAboutView setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [generalAboutView setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"", @"layer2_p.png",@"layer2.png", nil]];
    [generalAboutView setFontColorTitleAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    [generalAboutView setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [generalAboutView setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    [generalAboutView setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"",@"about-inkaspress-v.psd.png",@"about-inkaspress-h.psd.png", nil]];
    
    generalAboutView.alpha = 0;
    [generalAboutView reDraw];
    [self.view addSubview:generalAboutView];
    
    turismStore = [[XboxBackView alloc] initWithBackView: scroll Title:@"tourism magazines" Flecha:@"flecha.png"];  
    [turismStore setFrameAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{480,300}}", @"{{0,0},{768,1024}}",@"{{0,0},{1024,768}}", nil]];
    [turismStore setImageBackgroundColorAttribute:[NSArray arrayWithObjects:@"",@"", @"layer2_p.png",@"layer2.png", nil]];
    [turismStore setFontColorTitleAttribute:[NSArray arrayWithObjects:@"{{0,0},{320,460}}",@"{{0,0},{0,0}}", @"{{128,128},{128,1}}",@"{{128,128},{128,1}}", nil]];
    [turismStore setFontTitleAttribute:[NSArray arrayWithObjects:@"HelveticaNeue-Light",@"", @"HelveticaNeue-Light",@"HelveticaNeue-Light", nil]];
    [turismStore setFontSizeTitleAttribute:[NSArray arrayWithObjects:@"",@"", @"28",@"28", nil]];
    turismStore.alpha = 0;
    
    
    UIComicCollectionHorizontal *turismCollection = [[UIComicCollectionHorizontal alloc] initWithTitle:@""];
    [turismCollection setFrameAttribute:[turismStore getContentBounds]];
    Comic *comic0 = [[Comic alloc] init];
    NSMutableArray *volumes = [NSMutableArray array];
    
    NSArray *turismImages = [NSArray arrayWithObjects:
                             @"AFICHE MUSEO APURIMAC_thumb.png",
                             @"cover-colca_thumb.png",
                             @"COVERBOOK-AREQUIPA-2_thumb.png",
                             @"COVERBOOK-COLCA_thumb.png",
                             @"COVERBOOK-CUSCO_thumb.png",
                             @"COVERBOOK-LIMA-2_thumb.png",
                             @"COVERBOOK-TACNA-2_thumb.png",
                             @"peru_thumb.png",
                             @"truhiullo-cover_thumb.png", 
                             @"r_arequipa_thumb.png",
                             @"r_cusco_thumb.png",
                             @"r_la_libertad_thumb.png",
                             @"r_lima_thumb.png",
                             @"r_puno_thumb.png",
                             @"r_tacna_thumb.png", 

                             nil]; 
    
    for (NSString *str in turismImages) {
        [volumes addObject:[[Volume alloc] initWithImage:str]];
    }        
    comic0.volumes = [NSArray arrayWithArray:volumes];
    
    for (int k = 0; k < volumes.count; k++) {
        [turismCollection addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:comic0 ComicId:k]];
    }
   
    
    [turismStore addContent:turismCollection];
    
    [turismStore reDraw];
    [self.view addSubview:turismStore];
    
    
    
}

- (void) twitterTap:(id)sender{
    if ([TWTweetComposeViewController canSendTweet])
    {
        TWTweetComposeViewController *tweetSheet = [[TWTweetComposeViewController alloc] init];
        [tweetSheet setInitialText:@"Tweeting from Tukai! :)"];
        
        CGRect screenRect = scroll.frame;
        UIGraphicsBeginImageContext(screenRect.size);
        [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
        UIImage *parentViewImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        [tweetSheet addImage:parentViewImage];        
        
        
                
	    [self presentModalViewController:tweetSheet animated:YES];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Sorry" 
                                                            message:@"You can't send a tweet right now, make sure your device has an internet connection and you have at least one Twitter account setup" 
                                                           delegate:self 
                                                  cancelButtonTitle:@"OK" 
                                                  otherButtonTitles:nil];
        [alertView show];
    }
}

- (void) showGeneralAboutView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    generalAboutView.alpha = 1.0;
    scroll.alpha = 0.0;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];    
}

- (void) showTurismSoreView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    turismStore.alpha = 1.0;
    scroll.alpha = 0.0;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];    
}


- (void) showAboutView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    aboutView.alpha = 1.0;
    scroll.alpha = 0.0;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];    
}

-(void)closeFullScreenView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    backview.alpha = 1;    
    scroll.alpha = 0;
		
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];
}

- (void) showPublicityScreenView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    publicityView.alpha = 1.0;
    scroll.alpha = 0.0;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];    
}

- (void) showPublicity2ScreenView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    publicityView2.alpha = 1.0;
    scroll.alpha = 0.0;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];
    }

-(void)handleMyComics:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    comicListView.alpha = 1;
    scroll.alpha = 0;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [scroll reDraw];
    [backview reDraw];
    [comicListView reDraw];
    [publicityView reDraw];
    [publicityView2 reDraw];
    [aboutView reDraw];
    [generalAboutView reDraw];
    [turismStore reDraw];
}

@end
