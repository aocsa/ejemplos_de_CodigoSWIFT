//
//  UIGridImageView.h
//  iXbox
//
//  Created by Omar Mozo on 12/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIBaseView.h"
#import "UITickTransitionView.h"
#import "UITransitionOpacityView.h"
#import <objc/message.h>

@interface UIGridImageView : UIBaseView<UIGestureRecognizerDelegate>{
    NSArray *imageArray;
    NSArray *imageViewArray;
    NSArray *principalPointArray;
    NSArray *tailArray;
    
    id target;
    SEL action;
    
}
- (id) initWithImages:(NSArray *)images PrincipalPoints:(NSArray *)points;
- (NSArray *) getSizeOfImages;
- (void) setTails:(NSArray *)tails;
- (void) setTarget:(id)aTarget action:(SEL)anAction;
@end
