//
//  UIBaseView.h
//  iXbox
//
//  Created by Omar Mozo on 26/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface UIBaseView : UIView{
    NSMutableDictionary *attributes;    
}
- (id) initWithAttributes:(NSMutableDictionary *)attr;
- (void) reDraw;
- (void) setFrameAttribute:(NSArray *)frames;
- (NSArray *) getFrameAttribute;   
- (void) setImageBackgroundColorAttribute:(NSArray *)imageBackgroundColors;
- (NSArray *) getImageBackgroundColorAttribute; 
- (void) setFontTitleAttribute:(NSArray *)fonts;
- (NSArray *) getFontTitleAttribute;
- (void) setFontSizeTitleAttribute:(NSArray *)fontSizes;
- (NSArray *) getFontSizeTitleAttribute;
- (void) setFontColorTitleAttribute:(NSArray *)fontColors;
- (NSArray *) getFontColorTitleAttribute;
- (int) attributePositionToRedraw;
+ (int) orientation;
@end
