//
//  UITransitionView.h
//  iXbox
//
//  Created by Omar Mozo on 4/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "UITransitionBaseView.h"

@interface UITransitionOpacityView : UITransitionBaseView{   
    /**
     container that has the image that will be shown
     */
    UIImageView *imageView;
    /**
     grade of opacity.
     */
    CGFloat alpha;
}

+ (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize Image:(UIImage *)image principalPoint:(CGPoint)point;
@end
