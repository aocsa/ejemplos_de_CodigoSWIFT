//
//  UITickTransitionView.h
//  iXbox
//
//  Created by Omar Mozo on 6/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITransitionBaseView.h"
#import "SBTickerView.h"
#import "UITransitionOpacityView.h"


@interface UITickTransitionView : UITransitionBaseView{
    /**
     Object that perform the Tick down effect
     */
    SBTickerView *tickerView;
    /**
     let us know if the tick effect works Up or down.
     */
    int up;
}
- (void) isAnimationUp:(BOOL)isUp;

@end
