//
//  XboxBackView.h
//  iXbox
//
//  Created by Omar Mozo on 21/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIBaseView.h"

@class UIBaseView;
@interface XboxBackView : UIBaseView{
    UIButton *closeButton;
    UIBaseView *backView;
    UILabel *titleLabel; 
    UIBaseView *contentView;
    NSString *flechaImage;
}
@property(nonatomic,strong) UIBaseView *contentView;  

- (id) initWithBackView:(UIBaseView *) view Title: (NSString *)title Flecha:(NSString *)flecha;
- (void) addContent:(UIBaseView *) content;
- (NSArray *) getContentBounds;
@end
