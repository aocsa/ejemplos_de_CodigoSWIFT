//
//  UIComicItem.m
//  iXbox
//
//  Created by Omar Mozo on 27/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIComicItem.h"

#import <QuartzCore/QuartzCore.h>
#import "Issue.h"


@implementation UIComicItem
@synthesize isSelected,volume;

- (id)initWithManagedObjectContext:(Comic *) comic ComicId: (int) identifier
{
    self = [super initWithAttributes:nil];
    if (self) {
        isSelected = NO;
        volume = [comic getVolumeByIdentifier:identifier];
        self.layer.shadowOffset = CGSizeMake(0, 3);
        self.layer.shadowRadius = 5.0;
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:volume.image]];
        [self addSubview:imageView];
                
        volumeLabel = [[UILabel alloc] init];
        volumeLabel.text = volume.volume;  
    }
    return self;
}

- (id)initWithManagedObjectContext:(Volume *) volume1 
{
    self = [super initWithAttributes:nil];
    if (self) {
        isSelected = NO;
        volume = volume1;
        self.layer.shadowOffset = CGSizeMake(0, 3);
        self.layer.shadowRadius = 5.0;
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:volume.image]];
        [self addSubview:imageView];
        
        volumeLabel = [[UILabel alloc] init];
        volumeLabel.text = volume.volume;
    }
    return self;
}

- (id) initWithIssueModel:(Issue *)issue{
    self = [super initWithAttributes:nil];
    if (self) {
        isSelected = NO;        
        self.layer.shadowOffset = CGSizeMake(0, 3);
        self.layer.shadowRadius = 5.0;
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        
        imageView = [[UIImageView alloc] initWithImage:issue.coverImage];
        [self addSubview:imageView];
        
        volumeLabel = [[UILabel alloc] init];
        volumeLabel.text = issue.title;
    }
    return self;
}


- (void) reDraw{    
    [super reDraw];     
    volumeLabel.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height/8);
    imageView.frame = CGRectMake(3, 3, self.frame.size.width-3, self.frame.size.height-3);
    if (isSelected) {        
        self.layer.shadowOpacity = 0.8;    
        [self.superview bringSubviewToFront:self];
        [UIView animateWithDuration:0.45f delay:0.f options:UIViewAnimationOptionBeginFromCurrentState animations:^{
            self.transform = CGAffineTransformMakeScale(1.05, 1.05);
        } completion:nil];        
        volumeLabel.backgroundColor = [UIColor blueColor];
        volumeLabel.textColor = [UIColor whiteColor];        
    }else{
        self.layer.shadowOpacity = 0; 
        
        [UIView animateWithDuration:0.45f delay:0.f options:UIViewAnimationOptionBeginFromCurrentState animations:^{
            self.transform = CGAffineTransformIdentity;
        } completion:nil];
        
        volumeLabel.backgroundColor = [UIColor whiteColor];
        volumeLabel.textColor = [UIColor blackColor];
    }  
}
- (void) setOriginToComicItemView:(CGPoint)point{
    self.frame = CGRectMake(point.x, point.y, self.frame.size.width, self.frame.size.height);
}

@end
