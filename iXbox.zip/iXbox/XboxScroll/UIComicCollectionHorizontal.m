//
//  UIComicCollectionHorizontal.m
//  iXbox
//
//  Created by Omar Mozo on 28/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIComicCollectionHorizontal.h"
#import "Issue.h"
#import "Store.h"

@interface UIComicCollectionHorizontal() 
- (void) addGestureRecognizersToView:(UIView *)theView;
-(void) makeComicItemsNotSelected;
@end

@implementation UIComicCollectionHorizontal
@synthesize comicList;
@synthesize store = _store;
- (id)initWithTitle:(NSString *)title
{
    self = [super initWithTitle:title];
    if (self) {
        comicList = [NSMutableArray array];
        NSArray *columnRow = [NSArray arrayWithObjects:@"{2,2}",@"{1,3}",@"{3,4}",@"{2,5}", nil];
        [attributes setObject:columnRow forKey:@"columnRow"];    
        comicSelectedId = -1;
        comicDescription = [[UIComicItemDescription alloc] init];
        [scroll addSubview:comicDescription];
        //self.backgroundColor = [UIColor blackColor];
        combo1 = [[UIComboButton alloc] initWithDefaultOptionName:@"All categories"];
        [combo1 setTarget:self action:@selector(tapButton1:)];
        combo1.optionArray = [NSArray arrayWithObjects:@"comedy",@"story", nil];
        [self addSubview:combo1];
        
        combo2 = [[UIComboButton alloc] initWithDefaultOptionName:@"All Prices"];
        [combo2 setTarget:self action:@selector(tapButton2:)];
        combo2.optionArray = [NSArray arrayWithObjects:@"free",@"10$", nil];
        [self addSubview:combo2];
        
        combo3 = [[UIComboButton alloc] initWithDefaultOptionName:@"By newst"];
        [combo3 setTarget:self action:@selector(tapButton3:)];
        combo3.optionArray = [NSArray arrayWithObjects:@"recent",@"old", nil];
        [self addSubview:combo3];
        
        storeLabel = [[UILabel alloc] init];
        storeLabel.text = @"storeLabel";
        storeLabel.font = [UIFont fontWithName:@"HelveticaNeue-Light" size:24];
        storeLabel.textColor = [UIColor grayColor];
        storeLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:storeLabel];
        
        comicListTmp = [NSMutableArray array];
    }
    return self;
}

- (void) setFrameAttribute:(NSArray *)frames{
    [super setFrameAttribute:frames.copy];
    NSMutableArray *contentBounds = [NSMutableArray arrayWithArray:frames] ;
    for (int k =0 ; k<contentBounds.count ; k++) {        
        CGRect f = CGRectFromString([contentBounds objectAtIndex:k]);
        f.origin.x = 0;
        f.origin.y = 0;    
        f.size.width = 160;
        f.size.height = 220;
        [contentBounds replaceObjectAtIndex:k withObject:NSStringFromCGRect(f)];
    }
    comicItemBounds = contentBounds.copy;
}

- (void) reDraw{
    [super reDraw]; 
    [comicDescription hide];
    CGSize columnRow = CGSizeFromString([[attributes objectForKey:@"columnRow"] objectAtIndex:[self attributePositionToRedraw]]);
    scroll.frame = CGRectMake(self.frame.size.width/8, self.frame.size.height/5.5, columnRow.height*160, columnRow.width*220);    
    storeLabel.frame = CGRectMake(self.frame.size.width/8, 70, 100, 30);
    combo1.frame = CGRectMake(self.frame.size.width/8 + 150, 70, 150, 30);
    combo2.frame = CGRectMake(self.frame.size.width/8 + 300, 70, 150, 30);
    combo3.frame = CGRectMake(self.frame.size.width/8 + 450, 70, 150, 30);
    
    UIComicItem *comicItem = nil;
    comicItemXPos = 0;
    comicItemYPos = 0;
    
    int k;
    CGFloat comicDescriptionWidth = 0;
    
    for (k = 0; k<comicList.count; k++) {
        comicItem = [comicList objectAtIndex:k];
        [comicItem reDraw];
                        
        if(comicItemYPos+comicItem.frame.size.height>scroll.frame.size.height){
            if (comicDescriptionWidth >0) {
                comicItemXPos += comicDescriptionWidth;
                comicDescriptionWidth = 0;                
            }
            comicItemXPos += comicItem.frame.size.width;
            comicItemYPos = 0;
            [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
            [UIView setAnimationDuration:0.30];
            [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
            
            comicItem.frame = CGRectMake(comicItemXPos, comicItemYPos, comicItem.frame.size.width, comicItem.frame.size.height);
            
            [UIView setAnimationDelegate:self];    
            [UIView commitAnimations];
            
            
            comicItemYPos = comicItem.frame.size.height;            
        }else{
            [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
            [UIView setAnimationDuration:0.30];
            [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
            
            comicItem.frame = CGRectMake(comicItemXPos, comicItemYPos, comicItem.frame.size.width, comicItem.frame.size.height);
            
            [UIView setAnimationDelegate:self];    
            [UIView commitAnimations];
            comicItemYPos += comicItem.frame.size.height;            
        }
        if (k == comicSelectedId) {
            [comicDescription showAtFrame:CGRectMake(comicItemXPos+comicItem.frame.size.width, 0, comicItem.frame.size.width*2, scroll.frame.size.height) Volume:comicItem.volume];   
            comicDescriptionWidth = comicItem.frame.size.width*2;            
            
        }
    }
    if (comicItem != nil && comicSelectedId>0 && comicSelectedId<comicList.count) { 
        if(comicSelectedId == comicList.count-1) comicItemXPos += comicItem.frame.size.width*2;
        scroll.contentSize = CGSizeMake(comicItemXPos+comicItem.frame.size.width,columnRow.width*220);
        UIView *v = [comicList objectAtIndex:comicSelectedId];
        [scroll scrollRectToVisible:CGRectMake(v.frame.origin.x, v.frame.origin.y, scroll.frame.size.width, scroll.frame.size.height) animated:YES];
    }
    
    [self bringSubviewToFront:combo1];
    [self bringSubviewToFront:combo2];
    [self bringSubviewToFront:combo3];    
}

- (void) addComicResume: (UIComicItem *)comicItem{    
    [comicItem setFrameAttribute:comicItemBounds.copy];
    comicItem.layer.name = [NSString stringWithFormat:@"%i",comicList.count];
    [self addGestureRecognizersToView:comicItem];
    [scroll addSubview:comicItem];
    [comicList addObject:comicItem];
    Volume *v = [[Volume alloc] init];
    v.title = comicItem.volume.title;
    v.image = comicItem.volume.image;
    [comicListTmp addObject:v];
    
}

- (void) setStore:(Store *)store{
    _store = store;
    for ( int i = 0; i<[_store numberOfStoreIssues];i++) {
        Issue *issue = [_store issueAtIndex:i];
        [self addComicResume:[[UIComicItem alloc] initWithIssueModel:issue]];
    }
}

#pragma mark
#pragma mark UIGestureRecognizerDelegate methods
- (void) addGestureRecognizersToView:(UIView *)theView {
    theView.userInteractionEnabled = YES; 	
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
	[tapGesture setDelegate:self];
	[theView addGestureRecognizer:tapGesture];
}

-(void) handleTapGesture:(UITapGestureRecognizer *)gestureRecognizer{
    
    UIComicItem *comic = (UIComicItem *)gestureRecognizer.view;
    if (comicSelectedId != -1) ((UIComicItem *)[comicList objectAtIndex:comicSelectedId]).isSelected = NO;
    if(comicSelectedId != [comic.layer.name intValue]){
        
        ((UIComicItem *)[comicList objectAtIndex:[comic.layer.name intValue]]).isSelected = YES;
        comicSelectedId = [comic.layer.name intValue];
    }else{
        
        comicSelectedId = -1;
    }         
    [self reDraw];    
}
-(void) makeComicItemsNotSelected{
    for (UIComicItem *comicItem in comicList) {         
        comicItem.isSelected = NO;
    }
}

- (void) tapButton1:(NSString *)str{    
    if ([str isEqualToString:@"hola"]) {        
        [comicList removeObjectAtIndex:0];
        [comicList removeObjectAtIndex:1];
        [comicList removeObjectAtIndex:2];
    }else{
        
        
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:0]]];
        
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:1]]];
        
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:2]]];
    }    
    [self reDraw];
}
- (void) tapButton2:(NSString *)str{   
    
    if ([str isEqualToString:@"recent"] || [str isEqualToString:@"old"]) {
        [comicList exchangeObjectAtIndex:0 withObjectAtIndex:6];
        [comicList exchangeObjectAtIndex:1 withObjectAtIndex:5];
        [comicList exchangeObjectAtIndex:2 withObjectAtIndex:4];
    }
    [self reDraw];
}
- (void) tapButton3:(NSString *)str{   
    
    if ([str isEqualToString:@"free"]) {
        [comicList removeObjectAtIndex:0];
        [comicList removeObjectAtIndex:1];
        [comicList removeObjectAtIndex:2];
        [comicList removeObjectAtIndex:3];
        [comicList removeObjectAtIndex:4];
    }else{
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:0]]];        
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:1]]];        
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:2]]];
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:3]]];
        [self addComicResume:[[UIComicItem alloc] initWithManagedObjectContext:[comicListTmp objectAtIndex:4]]];
    }
    [self reDraw];
}
@end
