//
//  UIGridView.m
//  iXbox
//
//  Created by Omar Mozo on 30/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIGridView.h"
#import "UIChangeButton.h"

@implementation UIGridView

- (id)initWithTitle: (NSString *)title
{
    self = [super initWithAttributes:nil];
    self.userInteractionEnabled=YES;
    if (self) {
        views = [NSMutableArray array];
        buttonList = [NSMutableArray array];
        titleLayer = [[UILabel alloc] init];
        titleLayer.text = title;
        titleLayer.textColor = [UIColor grayColor];
        titleLayer.backgroundColor = [UIColor clearColor];
        [self addSubview:titleLayer];
        
        shadowDetail = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"layer26.png"]];
        [self addSubview:shadowDetail];        
    }
    return self;
}



- (void) reDraw{
    [super reDraw];    
    titleLayer.frame = CGRectMake(self.frame.size.width/10.4489796, self.frame.size.height/16.2, 210,29);
    
    titleLayer.font = [UIFont fontWithName:[[self getFontTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] size:[[[self getFontSizeTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] intValue]];
    
   
    UIView *v1,*v2,*v0;
    v0 = [views objectAtIndex:0]; 
    v1 = [views objectAtIndex:1]; 
    v2 = [views objectAtIndex:2]; 
    if ([UIBaseView orientation] == 0) {
        v1.frame = CGRectMake((self.frame.size.width-v1.frame.size.width)/2, self.frame.size.height/2-v1.frame.size.height, v1.frame.size.width, v1.frame.size.height);
        v0.frame = CGRectMake(v1.frame.origin.x, v1.frame.size.height+v1.frame.origin.y+5, v0.frame.size.width, v0.frame.size.height);
        v2.frame = CGRectMake(v0.frame.size.width + v0.frame.origin.x + 5, v1.frame.size.height+v1.frame.origin.y+5, v2.frame.size.width, v2.frame.size.height);
        shadowDetail.frame = CGRectMake(v0.frame.origin.x, v0.frame.origin.y+v0.frame.size.height+40, v1.frame.size.width, 45);
        
    } else { 
        v0.frame = CGRectMake(self.frame.size.width/5.7142857, self.frame.size.height/4.827911857, v0.frame.size.width, v0.frame.size.height); 
        v1.frame = CGRectMake(v0.frame.size.width+v0.frame.origin.x + 5, self.frame.size.height/4.827911857, v1.frame.size.width, v1.frame.size.height);
        v2.frame = CGRectMake(v1.frame.size.width+v1.frame.origin.x + 5, self.frame.size.height/4.827911857, v2.frame.size.width, v2.frame.size.height);
        shadowDetail.frame = CGRectMake(v0.frame.origin.x, v0.frame.origin.y+v0.frame.size.height+50, 825, 45);
    }       
    
    UIButton *button;
    buttonPos = self.frame.size.height/4.827911857;
    for (int k = 0; k<buttonList.count; k++) {
        button = [buttonList objectAtIndex:k];
        button.frame = CGRectMake(30, buttonPos, button.frame.size.width,  button.frame.size.height);
        buttonPos = buttonPos + button.frame.size.height +20;       
        
    } 
        
}

- (void) setSubViews: (NSMutableArray *) subViews{
    views = subViews;  
    for (UIView *v in subViews) {
        [self addSubview:v];
        [self bringSubviewToFront:v];
    }
}

- (void) addButton: (UIChangeButton *)button{
    [self addSubview:button];
    [buttonList addObject:button];
}

@end
