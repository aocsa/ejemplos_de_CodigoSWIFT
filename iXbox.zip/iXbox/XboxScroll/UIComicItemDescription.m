//
//  UIComicItemDescription.m
//  iXbox
//
//  Created by Omar Mozo on 29/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIComicItemDescription.h"
#import "UIBaseView.h"

@implementation UIComicItemDescription

- (id)init
{
    self = [super init];
    if (self) {
        titleLabel = [[UILabel alloc] init];
        titleLabel.textAlignment = UITextAlignmentCenter;        
        //[self addSubview:titleLabel];
        
        descriptionLabel = [[UILabel alloc] init];
        //descriptionLabel.text = volume.description;
        //[self addSubview:descriptionLabel];
        
        moreInfoButton = [UIButton buttonWithType:UIButtonTypeCustom];
        moreInfoButton.backgroundColor = [UIColor greenColor];
        [moreInfoButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [moreInfoButton setTitle:@"more info" forState:UIControlStateNormal];
        //[self addSubview:moreInfoButton];
        
        UIImage *img;
        
        fakeImage = [[UIImageView alloc] init];
        img = [UIImage imageNamed:@"coment0.png"];
        fakeImage.frame=CGRectMake(10, 10, img.size.width, img.size.height);
        fakeImage.image = img;
        [self addSubview:fakeImage];
        
        fakeScroll = [[UIScrollView alloc] init];
        img = [UIImage imageNamed:@"coment1.png"];
        fakeScroll.frame = CGRectMake(10, 218-50, 307, 400+50);
        
        
        fakeScrollSize = img.size;
        [fakeScroll addSubview:[[UIImageView alloc] initWithImage:img]];
        [self addSubview:fakeScroll];
        
        fakeButton = [[UIButton alloc] init];
        img = [UIImage imageNamed:@"coment2.png"];
        fakeButton.frame=CGRectMake(10, fakeScroll.frame.size.height+fakeScroll.frame.origin.y, img.size.width, img.size.height);
        //fakeButton.imageView = [[UIImageView alloc] initWithImage:img];
        [fakeButton setImage:img forState:UIControlStateNormal];
        [fakeButton addTarget:self action:@selector(doSearch:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:fakeButton];
        //self.backgroundColor = [UIColor redColor];
    }
    return self;
}

- (void) showAtFrame:(CGRect)frame Volume:(Volume *)volume{
    self.frame = frame;
    titleLabel.text = volume.title;
    titleLabel.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height/8);
    descriptionLabel.text = volume.description;    
    descriptionLabel.frame = CGRectMake(0, self.frame.size.height/8, self.frame.size.width, self.frame.size.height*6/8);
    moreInfoButton.frame = CGRectMake(0, self.frame.size.height*7/8, self.frame.size.width, self.frame.size.height/8);
    
    if ([UIBaseView orientation] == 0) {
        fakeScroll.frame =CGRectMake(10, 218-50, 307, 400+50);
        fakeScroll.contentSize = fakeScrollSize;
    }else{        
        fakeScroll.frame = CGRectMake(10, 218-50, 307, 180+50);
        fakeScroll.contentSize = fakeScrollSize;        
    }
    fakeButton.frame=CGRectMake(10, fakeScroll.frame.size.height+fakeScroll.frame.origin.y, fakeButton.frame.size.width, fakeButton.frame.size.height);
    
    self.transform = CGAffineTransformMakeScale(0.25, 0.25);
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    self.transform = CGAffineTransformIdentity;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];    
   
}
- (void) hide{
    self.frame = CGRectNull;
}

- (void) doSearch:(id)sender
{
    NSString *sstring = @"http://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?id=284417350&mt=8&uo=6";
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString:sstring]];
    
    /*NSString *stringURL = @"itms-books:";
    NSURL *url = [NSURL URLWithString:stringURL];
    [[UIApplication sharedApplication] openURL:url];
    
    NSString *stringURL = @"itms-bookss:";
    NSURL *url = [NSURL URLWithString:stringURL];
    [[UIApplication sharedApplication] openURL:url];*/
    
}

@end
