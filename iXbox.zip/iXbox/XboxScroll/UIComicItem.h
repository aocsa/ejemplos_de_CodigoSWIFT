//
//  UIComicItem.h
//  iXbox
//
//  Created by Omar Mozo on 27/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIBaseView.h"
#import "Comic.h"

@class Comic;
@class Issue;
@interface UIComicItem : UIBaseView{
    BOOL isSelected;
    UIImageView *imageView;
    UILabel *volumeLabel;
    Volume *volume;
}
@property(nonatomic,strong) Volume *volume;
@property(nonatomic) BOOL isSelected;
- (id)initWithManagedObjectContext:(Volume *) volume ;
- (id)initWithManagedObjectContext:(Comic *) comic ComicId: (int) identifier;
- (id) initWithIssueModel:(Issue *)issue;
- (void) setOriginToComicItemView:(CGPoint)point;
@end
