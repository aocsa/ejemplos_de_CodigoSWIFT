//
//  UIComicCollection.m
//  iXbox
//
//  Created by Omar Mozo on 26/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIComicCollection.h"
#import "UIBaseView.h"
#import "UIChangeButton.h"

@implementation UIComicCollection
@synthesize comicList,titleLayer,scroll;

- (id) initWithTitle: (NSString *)title;
{
    self = [super initWithAttributes:nil];
    if (self) {
        scroll = [[UIScrollView alloc] init];
        titleLayer = [[UILabel alloc] init];
        titleLayer.text = title; 
        titleLayer.textColor = [UIColor grayColor];
        titleLayer.backgroundColor = [UIColor clearColor];
        buttonList = [NSMutableArray array];
        [self addSubview:scroll];
        [self addSubview:titleLayer];
    }
    return self;
}

- (void) reDraw{      
    [super reDraw];
    titleLayer.frame = CGRectMake(self.frame.size.width/8, self.frame.size.height/20, self.frame.size.width*6/8, self.frame.size.height/20);
    
    titleLayer.font = [UIFont fontWithName:[[self getFontTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] size:[[[self getFontSizeTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] intValue]];
     
    UIButton *button;
    buttonPos = self.frame.size.height/4.827911857;
    for (int k = 0; k<buttonList.count; k++) {
        button = [buttonList objectAtIndex:k];
        button.frame = CGRectMake(30, buttonPos, button.frame.size.width,  button.frame.size.height);
        buttonPos = buttonPos + button.frame.size.height +20;        
    } 
    scroll.frame = self.bounds;    
    for (UIBaseView *view in scroll.subviews) {
        if([view isKindOfClass:[UIBaseView class]]) [view reDraw];
    }
}

- (void) addButton: (UIChangeButton *)button{
    [self addSubview:button];
    [buttonList addObject:button];
}

@end
