//
//  XboxBackView.m
//  iXbox
//
//  Created by Omar Mozo on 21/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "XboxBackView.h"
#import "XboxScrollView.h"

@implementation XboxBackView
@synthesize contentView;
- (id) initWithBackView:(UIBaseView *) view Title: (NSString *)title Flecha:(NSString *)flecha
{
    self = [super initWithAttributes:nil];
    if (self) {
        backView = view;
        
        contentView = [[UIBaseView alloc] initWithAttributes:nil];
        contentView.backgroundColor = [UIColor clearColor];
        [self addSubview:contentView];
        
        closeButton = [UIButton buttonWithType:UIButtonTypeCustom] ;
        [closeButton sizeToFit];
        [closeButton addTarget:self action:@selector(changeScreenView:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:closeButton];
        
        titleLabel = [[UILabel alloc] init];
        titleLabel.text = title;
        titleLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:titleLabel];
        
        flechaImage = flecha;
    }
    return self;
}

- (void) reDraw{
    [super reDraw];
    [closeButton setFrame:CGRectMake(self.frame.size.width/20, self.frame.size.height/20-12,88 , 111)];
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        [closeButton setImage:[UIImage imageNamed:flechaImage] forState:UIControlStateNormal];    
    }else{
        [closeButton setImage:[UIImage imageNamed:flechaImage] forState:UIControlStateNormal];    
    }
    titleLabel.textColor = [XboxScrollView getColorFromRect:CGRectFromString([[self getFontColorTitleAttribute] objectAtIndex:[self attributePositionToRedraw]])]; 
    titleLabel.font = [UIFont fontWithName:[[self getFontTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] size:[[[self getFontSizeTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] intValue]];
    titleLabel.frame = CGRectMake(closeButton.frame.origin.x+closeButton.frame.size.width+30, closeButton.frame.origin.y+35-6, self.frame.size.width-(closeButton.frame.origin.x+closeButton.frame.size.width),self.frame.size.height/20);    
    [contentView reDraw];
    for (id view in [contentView subviews]) {
        if([view isKindOfClass:[UIBaseView class]]) [view reDraw];
    }
}

- (void) addContent:(UIBaseView *) content{
    [contentView addSubview:content];
}

-(void)changeScreenView:(id)sender {
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    
    self.alpha = 0;
    backView.alpha = 1;
    
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];
}

- (NSArray *) getContentBounds{
    NSMutableArray *contentFrames = [NSMutableArray arrayWithArray:[self getFrameAttribute]] ;
    for (int k =0 ; k<contentFrames.count ; k++) {
        CGRect f = CGRectFromString([contentFrames objectAtIndex:k]);
        f.origin.x = 0;
        f.origin.y = f.size.height*2/20;
        f.size.height = f.size.height*19/20;
        [contentFrames replaceObjectAtIndex:k withObject:NSStringFromCGRect(f)];
    }
    [contentView setFrameAttribute:contentFrames];
    
    NSMutableArray *contentBounds = [NSMutableArray arrayWithArray:[self getFrameAttribute]] ;
    for (int k =0 ; k<contentBounds.count ; k++) {
        CGRect f = CGRectFromString([contentBounds objectAtIndex:k]);
        f.origin.x = 0;
        f.origin.y = 0;        
        [contentBounds replaceObjectAtIndex:k withObject:NSStringFromCGRect(f)];
    }
    return contentBounds;
}
@end
