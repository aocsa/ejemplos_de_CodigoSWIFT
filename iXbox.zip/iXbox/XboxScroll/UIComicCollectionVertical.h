//
//  UIComicCollectionVertical.h
//  iXbox
//
//  Created by Omar Mozo on 28/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIComicCollection.h"

@interface UIComicCollectionVertical : UIComicCollection{
    NSMutableArray *comicList;
    CGFloat comicResumePos;
}
- (void) addComicResume: (UIView *)comicResume;
@end
