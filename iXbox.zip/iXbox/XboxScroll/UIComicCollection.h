//
//  UIComicCollection.h
//  iXbox
//
//  Created by Omar Mozo on 26/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIBaseView.h"
#import <QuartzCore/QuartzCore.h>

@interface UIComicCollection : UIBaseView{
    UIScrollView *scroll;
    UILabel *titleLayer;    
    NSMutableArray *buttonList;
    CGFloat buttonPos;
}
@property(nonatomic,strong) UILabel *titleLayer;
@property(nonatomic,strong) NSArray *comicList;
@property(nonatomic, strong) UIScrollView *scroll;

- (id) initWithTitle: (NSString *)title;
- (void) addButton: (UIButton *)button;

@end
