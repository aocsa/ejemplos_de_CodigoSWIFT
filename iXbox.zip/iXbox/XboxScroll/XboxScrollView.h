//
//  XboxScrollView.h
//  iXbox
//
//  Created by Omar Mozo on 20/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "UIBaseView.h"

@interface XboxScrollView : UIBaseView<UIScrollViewDelegate,UIGestureRecognizerDelegate>{
    @private
    UIScrollView *scroll;
    NSMutableArray *titleArray;
    NSMutableArray *iconArray;
    int actualPage;
    CGFloat iconPos;
    CGFloat labelHeight;
}
@property(nonatomic) CGFloat labelHeight;
@property(nonatomic) int actualPage;

- (void) addIcon:(UIButton *)button;
- (void) addSubview:(UIBaseView *)view Title:(NSString *)title;
- (CGSize) contentSize;
- (void) refresh;

- (void) setTitleSelectedColorAttribute:(NSArray *)selectedColors;
- (NSArray *) getTitleSelectedColorAttribute;
- (void) setTitleUnselectedColorAttribute:(NSArray *)unselectedColors;
- (NSArray *) getTitleUnselectedColorAttribute;
+ (UIColor *) getColorFromRect:(CGRect) rectColor;

@end
