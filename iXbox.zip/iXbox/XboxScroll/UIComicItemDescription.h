//
//  UIComicItemDescription.h
//  iXbox
//
//  Created by Omar Mozo on 29/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Comic.h"

@interface UIComicItemDescription : UIView{
    UILabel *titleLabel;
    UILabel *descriptionLabel;
    UIButton *moreInfoButton;
    
    UIImageView *fakeImage;
    UIScrollView *fakeScroll;
    UIButton *fakeButton;
    
    CGSize fakeScrollSize;
    
}
- (void) showAtFrame:(CGRect)frame Volume:(Volume *)volume;
- (void) hide;
@end
