//
//  UIComicCollectionVertical.m
//  iXbox
//
//  Created by Omar Mozo on 28/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIComicCollectionVertical.h"

@implementation UIComicCollectionVertical

- (id)initWithTitle:(NSString *)title
{
    self = [super initWithTitle:title];
    if (self) {
        comicList = [NSMutableArray array];
        scroll.pagingEnabled = YES;
    }
    return self;
}

- (void) reDraw{
    [super reDraw];
    
    
    scroll.frame = ((UIView *)[comicList objectAtIndex:0]).frame;
    
    UIView *button;
    comicResumePos = 0;
    for (int k = 0; k<comicList.count; k++) {
        button = [comicList objectAtIndex:k];
        button.frame = CGRectMake(0, comicResumePos, scroll.frame.size.width,  scroll.frame.size.height);
        comicResumePos = comicResumePos + button.frame.size.height;      
        
    }
    scroll.contentSize = CGSizeMake(scroll.frame.size.width, comicResumePos);
    
}

- (void) addComicResume: (UIView *)comicResume{
    [scroll addSubview:comicResume];
    [comicList addObject:comicResume];
}

@end
