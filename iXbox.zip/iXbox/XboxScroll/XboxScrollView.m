//
//  XboxScrollView.m
//  iXbox
//
//  Created by Omar Mozo on 20/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "XboxScrollView.h"

@interface XboxScrollView()
- (void)addGestureRecognizersToView:(UIView *)theView;
- (void)handleTapGesture:(UITapGestureRecognizer *)gestureRecognizer;
@end

@implementation XboxScrollView
@synthesize labelHeight,actualPage;
- (id)init
{
    self = [super initWithAttributes:nil];
    if (self) {
        scroll = [[UIScrollView alloc] init];
        scroll.pagingEnabled = YES;
        scroll.delegate = self;
        scroll.backgroundColor = [UIColor clearColor];
    //    scroll.directionalLockEnabled = YES;
        [self addSubview:scroll];
        
        titleArray = [NSMutableArray array];
        iconArray = [NSMutableArray array];        
        actualPage = 0;  
        labelHeight = 0;                
    }
    return self;
}

- (void) reDraw{
    [super reDraw]; 
    int titleSpace = self.frame.size.width/10.24; 
        
    UILabel *label;    
    for (int k = 0; k<titleArray.count; k++) {
        label = [titleArray objectAtIndex:k];
        label.font = [UIFont fontWithName:[[self getFontTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] size:[[[self getFontSizeTitleAttribute] objectAtIndex:[self attributePositionToRedraw]] intValue]];
        label.frame = CGRectMake(titleSpace, labelHeight==0?self.frame.size.height/11.46:labelHeight, 110, 22);
        titleSpace += label.frame.size.width;
        
    }
    
    
    iconPos = self.frame.size.width/1.056;
    
    UIButton *button;
    for (int k = 0; k<iconArray.count; k++) {
        button = [iconArray objectAtIndex:k];
        //
        button.frame = CGRectMake(iconPos, self.frame.size.height/10.97142857-button.frame.size.height, button.frame.size.width, button.frame.size.height); 
        iconPos = iconPos-57;
    }
    CGRect frame = ((UILabel *)[titleArray lastObject]).frame;
    scroll.frame = CGRectMake(0, frame.size.height+frame.origin.y, self.frame.size.width, self.frame.size.height-frame.size.height-frame.origin.y);
    
    for (id view in [scroll subviews]) {
        if([view isKindOfClass:[UIBaseView class]]) [view reDraw];
        
    }
    
    scroll.contentSize = CGSizeMake(scroll.frame.size.width * titleArray.count, scroll.frame.size.height);
    [scroll scrollRectToVisible:CGRectMake(scroll.frame.size.width*actualPage, scroll.frame.origin.y, scroll.frame.size.width, scroll.frame.size.height) animated:YES];
}

- (void) setTitleSelectedColorAttribute:(NSArray *)selectedColors{
    [attributes setObject:selectedColors.copy forKey:@"selectedColors"];
}
- (NSArray *) getTitleSelectedColorAttribute{
    return [attributes objectForKey:@"selectedColors"];
}
- (void) setTitleUnselectedColorAttribute:(NSArray *)unselectedColors{
    [attributes setObject:unselectedColors.copy forKey:@"unselectedColors"];
}
- (NSArray *) getTitleUnselectedColorAttribute{
    return [attributes objectForKey:@"unselectedColors"];
}


- (void) addIcon:(UIButton *)button{
    [iconArray addObject:button];
}

- (void) addSubview:(UIBaseView *)view Title:(NSString *)title{
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = title;
    titleLabel.textColor = [UIColor grayColor];
    [self addGestureRecognizersToView:titleLabel];
    [self addSubview: titleLabel] ;
    [titleArray addObject:titleLabel];
    
    NSMutableArray *frames = [NSMutableArray arrayWithArray:[self getFrameAttribute]] ;
    for (int k =0 ; k<frames.count ; k++) {
        CGRect f = CGRectFromString([frames objectAtIndex:k]);
        f.origin.x = f.size.width * (titleArray.count -1);
        f.origin.y = 0;
        f.size.height = f.size.height*19/20;
        [frames replaceObjectAtIndex:k withObject:NSStringFromCGRect(f)];
    }
    
    [view setFrameAttribute:frames];
    [scroll addSubview:view];     
}

- (CGSize) contentSize{
    return scroll.frame.size;
}

- (void) refresh{
    [self scrollViewDidEndDecelerating:scroll];
}
#pragma mark
#pragma mark UIScrollViewDelegate methods

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    UILabel *titleLabel = [titleArray objectAtIndex:actualPage];
    titleLabel.textColor = [XboxScrollView getColorFromRect:CGRectFromString([[self getTitleUnselectedColorAttribute] objectAtIndex:[self attributePositionToRedraw]])];
    actualPage = scroll.contentOffset.x/scroll.frame.size.width;
    actualPage = actualPage<0||actualPage>=titleArray.count?0:actualPage;
    titleLabel = [titleArray objectAtIndex:actualPage];
    titleLabel.textColor = [XboxScrollView getColorFromRect:CGRectFromString([[self getTitleSelectedColorAttribute] objectAtIndex:[self attributePositionToRedraw]])];   
    [self reDraw];
}
#pragma mark
#pragma mark UIGestureRecognizerDelegate methods
- (void) addGestureRecognizersToView:(UIView *)theView {
    theView.userInteractionEnabled = YES;
	
	UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
	[tapGesture setDelegate:self];
	[theView addGestureRecognizer:tapGesture];
}

-(void) handleTapGesture:(UITapGestureRecognizer *)gestureRecognizer;{
    [scroll scrollRectToVisible:CGRectMake(scroll.frame.size.width*[titleArray indexOfObject:gestureRecognizer.view], scroll.frame.origin.y, scroll.frame.size.width, scroll.frame.size.height) animated:YES];
    UILabel *titleLabel = [titleArray objectAtIndex:actualPage];
    titleLabel.textColor = [XboxScrollView getColorFromRect:CGRectFromString([[self getTitleUnselectedColorAttribute] objectAtIndex:[self attributePositionToRedraw]])];
    actualPage = [titleArray indexOfObject:gestureRecognizer.view];
    titleLabel = [titleArray objectAtIndex:actualPage];
    titleLabel.textColor = [XboxScrollView getColorFromRect:CGRectFromString([[self getTitleSelectedColorAttribute] objectAtIndex:[self attributePositionToRedraw]])];
    [self reDraw];
}

+ (UIColor *) getColorFromRect:(CGRect) rectColor{
    return [UIColor colorWithRed:rectColor.origin.x/255 green:rectColor.origin.y/255 blue:rectColor.size.width/255 alpha:rectColor.size.height];
}
@end
