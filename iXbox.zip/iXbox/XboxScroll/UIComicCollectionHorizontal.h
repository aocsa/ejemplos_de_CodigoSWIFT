//
//  UIComicCollectionHorizontal.h
//  iXbox
//
//  Created by Omar Mozo on 28/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIComicCollection.h"
#import "UIComicItem.h"
#import "UIComicItemDescription.h"
#import "UIComboButton.h"
@class Store;

@interface UIComicCollectionHorizontal : UIComicCollection<UIGestureRecognizerDelegate>{
    NSMutableArray *comicList;
    NSMutableArray *comicListTmp;
    CGFloat comicItemXPos;
    CGFloat comicItemYPos;
    NSArray *comicItemBounds;
    int comicSelectedId;
    UIComicItemDescription *comicDescription;
    
    UILabel *storeLabel;
    UIComboButton *combo1;
    UIComboButton *combo2;
    UIComboButton *combo3;    
    
}
@property(nonatomic,strong) NSMutableArray *comicList;
@property (nonatomic,strong) Store *store;

- (void) addComicResume: (UIComicItem *)comicItem;
@end
