//
//  UIGridView.h
//  iXbox
//
//  Created by Omar Mozo on 30/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIBaseView.h"
#import <objc/message.h>
@class UIChangeButton;
@interface UIGridView : UIBaseView{
    NSMutableArray *views;
    NSMutableArray *buttonList;
    UILabel *titleLayer;
    CGFloat buttonPos;
    /**
     Image that is above the grid
     */
    UIImageView *shadowDetail;
    
    
    
}
- (id)initWithTitle: (NSString *)title;
- (void) setSubViews: (NSArray *) subViews;
- (void) addButton:(UIChangeButton *)button;

@end
