//
//  UITickTransitionMedia2.m
//  iXbox
//
//  Created by Omar Mozo on 12/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UITickTransitionMedia2.h"

@implementation UITickTransitionMedia2
/**
 This is the constructor redefined, where the tickerView object is created and added to this view
 and for default the animation id down.
 */
- (id) initWithFrame:(CGRect)frame ImageArray:(NSArray *)images{
    self = [super initWithFrame:frame ImageArray:images];
    if (self) {
        tickerView = [[SBTickerView alloc] initWithFrame:self.bounds];
        
        
        
        UIButton *videoButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [videoButton addTarget:self action:@selector(playVideo:) forControlEvents:UIControlEventTouchUpInside];
        videoButton.frame = self.bounds;
        [videoButton setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@.png", [imageArray objectAtIndex:posImage]]] forState:UIControlStateNormal];
        //[tickerView setFrontView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:[imageArray objectAtIndex:posImage]]]];     
        [tickerView setFrontView:videoButton];
        [self addSubview:tickerView];
        up = 0;
        
        videoPlayer = [[UIView alloc] initWithFrame:self.bounds];
        //videoPlayer.backgroundColor = [UIColor redColor];
        videoPlayer.alpha = 0.0;
        [self addSubview:videoPlayer];
    }
    return self;
}
/**
 this method says the way how the animations should work Upd or Down.
 */
- (void) isAnimationUp:(BOOL)isUp{
    up = isUp?1:0;
}
/**
 Perform the animation, changing the backimage and say that it should change.
 */
- (void)animation:(id)sender{
    [super animation:sender];
    UIButton *videoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [videoButton addTarget:self action:@selector(playVideo:) forControlEvents:UIControlEventTouchUpInside];
    [videoButton setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@.png", [imageArray objectAtIndex:posImage]]] forState:UIControlStateNormal];
    [tickerView setBackView:videoButton];
    //[tickerView setBackView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:[imageArray objectAtIndex:posImage]]]];
    [tickerView tick:up animated:YES completion:nil];
    
}

- (void) playVideo:(id)sender {
    [self stop];
    NSURL *url = [[NSURL alloc] initFileURLWithPath: [[NSBundle mainBundle] pathForResource:[imageArray objectAtIndex:posImage] ofType:@"mp4"]];
    
    /*MPMoviePlayerController **/moviePlayer = 
    [[MPMoviePlayerController alloc] initWithContentURL:url];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:moviePlayer];
    
    moviePlayer.controlStyle = MPMovieControlStyleNone;  
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(enteredFullscreen:)
                                                 name:MPMoviePlayerDidEnterFullscreenNotification
                                               object:moviePlayer];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(exitedFullscreen:)
                                                 name:MPMoviePlayerDidExitFullscreenNotification
                                               object:moviePlayer];
    
 
    moviePlayer.shouldAutoplay = YES;
    [moviePlayer prepareToPlay];
    [moviePlayer.view setFrame: videoPlayer.bounds];
    [videoPlayer addSubview:moviePlayer.view];
    videoPlayer.alpha=1.0;
    tickerView.alpha=0.0;
}

- (void)enteredFullscreen:(NSNotification*)notification {
    moviePlayer.controlStyle = MPMovieControlStyleEmbedded;  
    NSLog(@"enteredFullscreen");
}

- (void)exitedFullscreen:(NSNotification*)notification {
    NSLog(@"exitedFullscreen");
    moviePlayer.controlStyle = MPMovieControlStyleNone;  
}

- (void) moviePlayBackDidFinish:(NSNotification*)notification {
    
    //MPMoviePlayerController *moviePlayer = [notification object];
    
    /*[[NSNotificationCenter defaultCenter] removeObserver:self      
                                                    name:MPMoviePlayerPlaybackDidFinishNotification
                                                  object:moviePlayer];*/
    
    /*if ([moviePlayer 
         respondsToSelector:@selector(setFullscreen:animated:)])
    {*/
        //[moviePlayer.view removeFromSuperview];
    //}
    //[moviePlayer release];
    
    moviePlayer = nil;
    
    videoPlayer.alpha=0.0;
    tickerView.alpha=1.0;
    [self start];   
}
@end
