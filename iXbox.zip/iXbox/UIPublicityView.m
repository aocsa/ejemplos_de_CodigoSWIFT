//
//  UIPublicityView.m
//  iXbox
//
//  Created by Omar Mozo on 10/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIPublicityView.h"

@implementation UIPublicityView
@synthesize imagePos;

- (id) initWithImages:(UITransitionOpacityView *)images Videos:(UITransitionOpacityView *)videos{
    self = [super initWithAttributes:nil];
    if (self) {
        transitionView = images;
        [transitionView start];
        [self addSubview:transitionView];
        
        backgroundImage = [[UIImageView alloc] init];
        [self addSubview:backgroundImage];
        
        transitionMediaView = videos;
        [transitionMediaView start];
        [self addSubview:transitionMediaView];
        
        imagePos = 0;
    }
    return self;
}
- (void) reDraw{
    [super reDraw];
    imagePos = ((XboxScrollView *)self.superview.superview).actualPage;
    
    NSString *img = [[[self getImageBackgroundColorAttribute] objectAtIndex:[self attributePositionToRedraw]] objectAtIndex:imagePos];
    
    backgroundImage.image = [UIImage imageNamed:img];
    
    if (img) {
        [self.superview.superview setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:[NSString stringWithFormat:@"b_%@",img]]]];
    }else{
        [self.superview.superview setBackgroundColor:[UIColor whiteColor]];
    }
    
    
    if ([UIBaseView orientation] == 0) {        
        transitionMediaView.frame = CGRectMake(70, 631, 266, 159);
        transitionView.frame = CGRectMake(0, 0, 768, 576);
        backgroundImage.frame = CGRectMake(0, 530, 768, 328);
    }else{
        transitionMediaView.frame = CGRectMake(24, 230, 266, 159);
        transitionView.frame = CGRectMake(263, 6, 768, 576);
        backgroundImage.frame = CGRectMake(0, 6, 340, 572);
    }
    //[self bringSubviewToFront:scrollView];
    //[self sendSubviewToBack:transitionView];
}
@end
