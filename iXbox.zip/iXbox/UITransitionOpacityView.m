//
//  UITransitionView.m
//  iXbox
//
//  Created by Omar Mozo on 4/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UITransitionOpacityView.h"

@implementation UITransitionOpacityView

/**
 Constructor redefined to inicialize the image view.
 */
- (id) initWithFrame:(CGRect)frame ImageArray:(NSArray *)images{
    self = [super initWithFrame:frame ImageArray:images];
    if (self) {
        imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        /*if (posImage == 3) {
            imageView.image = [UITransitionOpacityView imageByScalingAndCroppingForSize:self.frame.size Image:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] principalPoint:self.center];
        } else {*/
            imageView.image = [UIImage imageNamed:[imageArray objectAtIndex:posImage]];
        //}
        
        [self nextImage];
        [self addSubview:imageView]; 
        alpha=1.0;
        timeInterval = 4.0;
    }
    return self;
}
/**
 perform the effect
 */
- (void) animation:(id)sender{    
    [super animation:sender];
    [UIView beginAnimations:@"" context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelay:0.0];
    //[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];    
    self.alpha = alpha;     
    [UIView commitAnimations];
    
    [super animation:sender];
    [UIView beginAnimations:@"" context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationDelay:0];
    //[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];    
    self.alpha = alpha;     
    [UIView commitAnimations];
}

/**
 here is checked if the opacity is low to change de image and make the opacity will be huge to get the effect.
 */
- (void) nextImage{    
    if (alpha == 1) {
        alpha = 0.1;
        
    }else{
        //CGRect f= self.frame;
        
        alpha = 1;
        //UIImage *im = [UIImage imageNamed:[imageArray objectAtIndex:posImage]];
        
        //if (posImage == 3) {
            imageView.image = [UITransitionOpacityView imageByScalingAndCroppingForSize:self.frame.size Image:[UIImage imageNamed:[imageArray objectAtIndex:posImage]] principalPoint:self.center];
        //} else {
        //    imageView.image = [UIImage imageNamed:[imageArray objectAtIndex:posImage]];
        //}
        
        [super nextImage];
        
    }   
}

- (void) setFrame:(CGRect)frame{
    [super setFrame:frame];
    imageView.frame = self.bounds;
}

+ (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize Image:(UIImage *)image principalPoint:(CGPoint)point
{
    UIImage *sourceImage = image;
    UIImage *newImage = nil;        
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointZero;
    CGPoint principalPoint = CGPointMake(.5, 1.0);//CGPointMake(point.x/width, point.y/width);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO) 
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor) 
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * principalPoint.y; 
        }
        else 
            if (widthFactor < heightFactor)
            {
                thumbnailPoint.x = (targetWidth - scaledWidth) * principalPoint.x;
            }
    }       
    
    UIGraphicsBeginImageContext(targetSize); // this will crop
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil) 
        NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}
@end
