//
//  iXboxViewController.h
//  iXbox
//
//  Created by Omar Mozo on 20/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import "UIChangeButton.h"
#import "UIPublicityView.h"
#import "UITickTransitionMedia.h"
#import "UITickTransitionMedia2.h"
#import "UIGridImageView.h"
#import "UIComicCarousel.h"


@class XboxScrollView;
@class XboxBackView;
@class Store;
@class UIComicItemDescription;


@interface iXboxViewController : UIViewController{
    XboxScrollView *scroll;
    XboxBackView *backview;
    XboxBackView *comicListView;
    XboxBackView *publicityView;
    XboxBackView *publicityView2;
    XboxBackView *aboutView;
    
    XboxBackView *generalAboutView;
    XboxBackView *turismStore;
    
    Store *store;
}

@property (nonatomic,strong) Store *store;

@end
