//
//  AppDelegate.h
//  iXbox
//
//  Created by Omar Mozo on 20/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iXboxViewController.h"
#import "Store.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) iXboxViewController *viewController;
@property (strong, nonatomic) Store *store;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@end
