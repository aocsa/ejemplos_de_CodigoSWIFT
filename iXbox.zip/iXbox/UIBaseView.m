//
//  UIBaseView.m
//  iXbox
//
//  Created by Omar Mozo on 26/12/11.
//  Copyright (c) 2011 Tukai. All rights reserved.
//

#import "UIBaseView.h"
#import "AppDelegate.h"

@implementation UIBaseView

- (id)initWithAttributes:(NSMutableDictionary *)attr
{
    self = [super init];
    if (self) {
        if (attr == nil)  attributes = [NSMutableDictionary dictionary];
        else attributes = attr;       
    }
    return self;
}

- (void) setFrameAttribute:(NSArray *)frames{    
    [attributes setObject:frames.copy forKey:@"frame"];
}

- (NSArray *) getFrameAttribute{
    return [attributes objectForKey:@"frame"];
}

- (void) setImageBackgroundColorAttribute:(NSArray *)imageBackgroundColors{    
    [attributes setObject:imageBackgroundColors.copy forKey:@"imageBackgroundColor"];
}

- (NSArray *) getImageBackgroundColorAttribute{
    return [attributes objectForKey:@"imageBackgroundColor"];
}

- (void) setFontTitleAttribute:(NSArray *)fonts{    
    [attributes setObject:fonts.copy forKey:@"fontTitle"];
}

- (NSArray *) getFontTitleAttribute{
    return [attributes objectForKey:@"fontTitle"];
}

- (void) setFontColorTitleAttribute:(NSArray *)fontColors{    
    [attributes setObject:fontColors.copy forKey:@"fontColorTitle"];
}

- (NSArray *) getFontColorTitleAttribute{
    return [attributes objectForKey:@"fontColorTitle"];
}

- (void) setFontSizeTitleAttribute:(NSArray *)fontSizes{    
    [attributes setObject:fontSizes.copy forKey:@"fontSizeTitle"];
}

- (NSArray *) getFontSizeTitleAttribute{
    return [attributes objectForKey:@"fontSizeTitle"];
}

- (void) reDraw{  
    
    @try {
        self.frame = CGRectFromString([[attributes objectForKey:@"frame"] objectAtIndex:[self attributePositionToRedraw]]);
    }
    @catch (NSException *exception) {
        NSLog(@"Non Frame Found Exception: %@",exception);
    }    
    
    @try {
        self.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:[[self getImageBackgroundColorAttribute] objectAtIndex:[self attributePositionToRedraw]]]];
    }
    @catch (NSException *exception) {
        NSLog(@"Non ImageBackground Found Exception: %@",exception);
    }    
    
}
- (int) attributePositionToRedraw{
    int index = [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone ? 0 : 2;
    index += [UIBaseView orientation];
    return index;
}
+ (int) orientation{
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];    
    CGSize size = delegate.viewController.view.bounds.size;
    return size.width<size.height?0:1;
}
@end
