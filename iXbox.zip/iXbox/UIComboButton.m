//
//  UIComboButton.m
//  iXbox
//
//  Created by Yuber on 1/25/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIComboButton.h"

@implementation UIComboButton
@synthesize optionArray;

- (id)initWithDefaultOptionName:(NSString *)defaultName {
    self = [super init];
    if (self) {
        buttonSelection = [UIButton buttonWithType:UIButtonTypeCustom];
        buttonSelection.frame = self.bounds;
        [buttonSelection addTarget:self action:@selector(handleTap:) forControlEvents:UIControlEventTouchUpInside];
        [buttonSelection setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [buttonSelection setTitleColor:[UIColor blackColor] forState:UIControlEventTouchUpInside];
        [buttonSelection setTitle:defaultName forState:UIControlStateNormal];
        //[buttonSelection setImage:[UIImage imageNamed:@"borderButton.png"] forState:UIControlStateNormal];
        buttonSelection.layer.borderColor = [UIColor blackColor].CGColor;
        buttonSelection.layer.borderWidth = 1.0;
        [self addSubview:buttonSelection];
        comboMore = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"comboMore.png"]];
        [buttonSelection addSubview:comboMore];
        
        optionScroll = [[UIScrollView alloc] init];
        optionScroll.backgroundColor = [UIColor whiteColor];
        [self addSubview:optionScroll];          
        self.clipsToBounds = NO;
        //self.backgroundColor = [UIColor blackColor];
        firstTime = YES;
        selectionOpen = NO;
        
        optionScroll.layer.borderColor = [UIColor blackColor].CGColor;
        optionScroll.layer.borderWidth = 1.0;
        
        
        [buttonSelection setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }
    return self;
}

- (void) setFrame:(CGRect)frame{
    [super setFrame:frame];
    buttonSelection.frame=self.bounds;
    comboMore.frame = CGRectMake(buttonSelection.frame.size.width-20, 12, 12, 9);
    if (firstTime) {
        originalFrame = frame;
        firstTime = NO;
        for (int i=0;i<optionArray.count;i++) {
            UIButton *b = [optionButtonArray objectAtIndex:i];
            b.frame = CGRectMake(0, i*self.frame.size.height, self.frame.size.width, self.frame.size.height);       
        }
    }
    
    
    
}

- (void) setOptionArray:(NSArray *)optionArray2{
    optionArray = optionArray2;
    optionButtonArray = [NSMutableArray array];
    for (int i=0;i<optionArray.count;i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = i;
        [b setTitle:[optionArray objectAtIndex:i] forState:UIControlStateNormal];
        [b setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [b addTarget:self action:@selector(tapOption:) forControlEvents:UIControlEventTouchUpInside]; 
        [b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [optionScroll addSubview:b];
        [optionButtonArray addObject:b];
        //optionScroll.backgroundColor = [UIColor redColor];
    }
}

/*- (id)initWithFrame:(CGRect)frame Options:(NSArray *)options orientation:(BOOL) orientation
{
    self = [super initWithFrame:frame];
    if (self) {
        buttonSelection = [UIButton buttonWithType:UIButtonTypeCustom];
        buttonSelection.frame = self.bounds;
        [buttonSelection addTarget:self action:@selector(handleTap:) forControlEvents:UIControlStateNormal];
        [self addSubview:buttonSelection];
        
        optionScroll = [[UIScrollView alloc] init];
        [self addSubview:optionScroll];
        
        optionArray = options;
        _orientation = orientation;
        
        self.clipsToBounds = NO;
              
        //NSString *option;
        for (int i=0;i<optionArray.count;i++) {
            UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
            b.tag = i;
            [b setTitle:[optionArray objectAtIndex:i] forState:UIControlStateNormal];
            [b addTarget:self action:@selector(tapOption:) forControlEvents:UIControlStateNormal];
            b.frame = CGRectMake(0, i*self.frame.size.height, self.frame.size.width, self.frame.size.height);
            [optionScroll addSubview:b];
        }
    }
    return self;
}*/

-(void)handleTap:(id)sender {
    if (!selectionOpen) {
        buttonSelection.layer.backgroundColor = [UIColor colorWithRed:51.0/255 green:153.0/255 blue:254.0/255 alpha:1.0].CGColor;
        [buttonSelection setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        CGRect frame;
        CGSize size; 
        size = CGSizeMake(self.frame.size.width, optionArray.count*self.frame.size.height);
        if (optionArray.count <5) {
            frame = CGRectMake(0, self.frame.size.height, self.frame.size.width, optionArray.count*self.frame.size.height);
            
        }else{
            frame = CGRectMake(0, self.frame.size.height, self.frame.size.width, optionArray.count*6);
            
        }
        
        [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
        [UIView setAnimationDuration:0.30];
        [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
        optionScroll.frame = frame;
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width,frame.origin.y+frame.size.height);
        
        [UIView setAnimationDelegate:self];    
        [UIView commitAnimations];
        optionScroll.contentSize = size;
        selectionOpen = YES;
    }
    
}

-(void)tapOption:(id)sender {
    UIButton *b = (UIButton *)sender;
    buttonSelection.layer.backgroundColor = [UIColor clearColor].CGColor;
    [buttonSelection setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [buttonSelection setTitle:[optionArray objectAtIndex:b.tag] forState:UIControlStateNormal];
    [buttonSelection setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [UIView beginAnimations:@"CLOSEFULLSCREEN" context:NULL];
    [UIView setAnimationDuration:0.30];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:nil cache:YES];
    optionScroll.frame = CGRectZero;  
    self.frame = originalFrame;
    [UIView setAnimationDelegate:self];    
    [UIView commitAnimations];
    
    //[target performSelector:action withObject:[optionArray objectAtIndex:b.tag]];
    objc_msgSend(target, action,[optionArray objectAtIndex:b.tag]);
    
    selectionOpen = NO;
}

- (void) setTarget:(id)aTarget action:(SEL)anAction{
    target = aTarget;
    action = anAction;
}
@end
