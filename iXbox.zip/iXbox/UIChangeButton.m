//
//  UIChangeButton.m
//  iXbox
//
//  Created by Omar Mozo on 9/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import "UIChangeButton.h"

@implementation UIChangeButton
/**
 Constructor that inicialize the image and title
 */
- (id) initWithFrame:(CGRect) frame Image:(UIImage *) image Title:(NSString *)title{
    self = [super initWithFrame:frame];
    if (self) {  
        imageView = [[UIImageView alloc] initWithImage:image];
        imageView.frame = CGRectMake(self.frame.size.width/2-25, self.frame.size.height-52, 25, 22);
        imageView.backgroundColor = [UIColor clearColor];
        [self addSubview:imageView];
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, self.frame.size.height-20, self.frame.size.width-10, 20)];
        titleLabel.text = title;
        titleLabel.textColor = [UIColor whiteColor];   
        titleLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:titleLabel];
        
        numberLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.width/2+5, self.frame.size.height-52, self.frame.size.width/2, 22)];
        numberLabel.text = [NSString stringWithFormat:@"%i",0];
        numberLabel.textColor = [UIColor whiteColor];
        numberLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:35];
        numberLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:numberLabel];
    }
    return self;
}
/**
 change de value of the number that is shown at numberLabel, animated
 */
- (void) changeNumberValue:(int) number{
    numberLabel.text = [NSString stringWithFormat:@"%i",number];
    [self reDraw];
    //needs animation!!!
}
/**
 here the image number and title are relocated
 */
- (void)reDraw{
    
}
@end
