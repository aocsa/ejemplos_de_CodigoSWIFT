//
//  UITickTransitionMedia2.h
//  iXbox
//
//  Created by Omar Mozo on 12/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>
#import "UITransitionBaseView.h"
#import "SBTickerView.h"

@interface UITickTransitionMedia2 : UITransitionBaseView{
    /**
     Object that perform the Tick down effect
     */
    SBTickerView *tickerView;
    /**
     let us know if the tick effect works Up or down.
     */
    int up;
    UIView *videoPlayer;
    MPMoviePlayerController *moviePlayer;
}
- (void) isAnimationUp:(BOOL)isUp;
@end
