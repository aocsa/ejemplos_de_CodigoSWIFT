//
//  UITickTransitionMedia.h
//  iXbox
//
//  Created by Omar Mozo on 11/01/12.
//  Copyright (c) 2012 Tukai. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>
#import "UIBaseView.h"
#import "UITransitionBaseView.h"
#import "SBTickerView.h"

@interface UITickTransitionMedia : UITransitionBaseView{
    /**
     Object that perform the Tick down effect
     */
    SBTickerView *tickerView;
    /**
     let us know if the tick effect works Up or down.
     */
    int up;    
    MPMoviePlayerController *moviePlayer1;
    MPMoviePlayerController *moviePlayer2;
}
@end
