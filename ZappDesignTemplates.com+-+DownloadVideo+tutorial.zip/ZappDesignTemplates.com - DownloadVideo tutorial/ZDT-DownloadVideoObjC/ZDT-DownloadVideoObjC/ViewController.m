//
//  ViewController.m
//  ZDT-DownloadVideoObjC
//
//  Created by Szabolcs Sztanyi on 15/04/15.
//  Copyright (c) 2015 Szabolcs Sztanyi. All rights reserved.
//

#import "ViewController.h"
#import "DownloadButton.h"
#import "ProgressView.h"

@interface ViewController () <NSURLSessionDownloadDelegate>
@property (nonatomic, strong) NSURLSessionDownloadTask *downloadTask;
@end

@implementation ViewController

- (IBAction)downloadButtonPressed:(DownloadButton*)button
{
    if (self.downloadTask) {
        [self.downloadTask cancel];
        self.statusLabel.text = @"";
    }
    else
    {
        self.statusLabel.text = @"Downloading video";
        [button setTitle:@"Stop download" forState:UIControlStateNormal];
        [self createDownloadTask];
    }
}

- (void)createDownloadTask
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"https://www.dropbox.com/s/r6lr4zlw12ipafm/SpeedTracker_movie.mov?dl=1"]];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]
                                                          delegate:self
                                                     delegateQueue:[NSOperationQueue mainQueue]];
    self.downloadTask = [session downloadTaskWithRequest:request];
    [self.downloadTask resume];
}

- (void)resetView
{
    [self.downloadButton setTitle:@"Start download" forState:UIControlStateNormal];
    [self.downloadTask cancel];
}

#pragma mark - download task delegates
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didFinishDownloadingToURL:(NSURL *)location
{
    self.statusLabel.text = @"Download finished";
    [self resetView];
}

- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)downloadTask didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)totalBytesWritten totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite
{
    float progress = (float)totalBytesWritten / (float)totalBytesExpectedToWrite;
    [self.progressView animateProgressViewToProgress:progress];
    [self.progressView updateProgressViewLabelWithProgress:(progress * 100)];
    [self.progressView updateProgressViewWithTotalSent:totalBytesWritten andTotalFileSize:totalBytesExpectedToWrite];
}

- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error
{
    if (error) {
        self.statusLabel.text = @"Download failed";
    } else {
        self.statusLabel.text = @"Download finished";
    }
    [self resetView];
}

#pragma mark - view methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.statusLabel.text = @"";
    [self addGradientBackgroundLayer];
}

- (void)addGradientBackgroundLayer
{
    CAGradientLayer *gradientLayer = [CAGradientLayer new];
    gradientLayer.frame = self.view.frame;
    
    gradientLayer.colors = @[(id)[UIColor colorWithRed:73.0/255.0 green:223.0/255.0 blue:185.0/255.0 alpha:1.0].CGColor,
                             (id)[UIColor colorWithRed:36.0/255.0 green:115.0/255.0 blue:192.0/255.0 alpha:1.0].CGColor];
    gradientLayer.locations = @[@(0.0), @(1.0)];
    [self.view.layer insertSublayer:gradientLayer atIndex:0];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
