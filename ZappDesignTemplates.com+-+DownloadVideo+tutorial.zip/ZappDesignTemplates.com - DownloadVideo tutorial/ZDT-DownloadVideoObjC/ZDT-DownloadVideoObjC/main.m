//
//  main.m
//  ZDT-DownloadVideoObjC
//
//  Created by Szabolcs Sztanyi on 15/04/15.
//  Copyright (c) 2015 Szabolcs Sztanyi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
