//
//  ViewController.h
//  ZDT-DownloadVideoObjC
//
//  Created by Szabolcs Sztanyi on 15/04/15.
//  Copyright (c) 2015 Szabolcs Sztanyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ProgressView, DownloadButton;

@interface ViewController : UIViewController

@property (nonatomic, weak) IBOutlet UILabel *statusLabel;
@property (nonatomic, weak) IBOutlet ProgressView *progressView;
@property (nonatomic, weak) IBOutlet DownloadButton *downloadButton;

- (IBAction)downloadButtonPressed:(DownloadButton*)button;


@end
