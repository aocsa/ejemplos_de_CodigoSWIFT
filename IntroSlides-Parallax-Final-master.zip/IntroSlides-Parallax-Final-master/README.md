

This a the final project for Intro Slides Tutorial found on youtube.

https://www.youtube.com/channel/UCkDH_a13ltiVPqJDXsbGrZw
