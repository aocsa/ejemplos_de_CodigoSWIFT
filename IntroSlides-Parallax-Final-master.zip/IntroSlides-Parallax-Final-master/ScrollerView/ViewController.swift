//
//  ViewController.swift
//  ScrollerView
//
//  Created by Jad Habal on 2017-01-17.
//  Copyright © 2017 Jadhabal. All rights reserved.
//

import UIKit


class ViewController: UIViewController{
    
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Let's load our SlidesInfo
        let info = LoadSlidesPlistFile()
        
        
        //Let's set the pageControl number of pages so we can see the dots
        self.pageControl.numberOfPages = info.count
        
        
        //let's set the scrollView properties
        self.scrollView.isPagingEnabled = true //This one we can make it false and disable the snapping effect
        
        self.scrollView.bounces = false
        self.scrollView.delegate = self
        
        
        //Build slides view
        self.setupSlides(slides: info)
    }
    
    var slidesViews = [Slide]()
    func setupSlides(slides:[SlideInfoModel]){
        
        //Let's build our slides
        
        for i in 0..<slides.count{
        
            let slide = Slide(frame: CGRect(origin: CGPoint(), size: UIScreen.main.bounds.size))
            slide.index = i
            slide.frame.origin.x = CGFloat(i) * UIScreen.main.bounds.size.width
            slide.backgroundImage.image = UIImage.init(named: slides[i].imageName)
            slide.title.text = slides[i].title
            slide.descriptionLabel.text = slides[i].description
            
            self.scrollView.addSubview(slide)
            self.slidesViews.append(slide)
        
        }
        
        
        
        //Now let's calculate the content width
        let contenWidth = UIScreen.main.bounds.size.width * CGFloat(slides.count)
        
        //Let's set the scrollView ContentSize
        self.scrollView.contentSize = CGSize(width: contenWidth, height: UIScreen.main.bounds.size.height)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //This way the first slide will begin zooming
        self.scrollViewDidEndDecelerating(self.scrollView)
    }
 
}

//We will be interessted in two delegate methods of UIScrollViewDelegate

extension ViewController:UIScrollViewDelegate{
    
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        
        //let's update the PageControl with the currentPage number
        
        let currentPage = Int(self.scrollView.contentOffset.x / UIScreen.main.bounds.size.width)
        self.pageControl.currentPage = currentPage
        
        
        //Let's do the zooming effect
        let imageView = self.slidesViews[currentPage].backgroundImage
        
        UIView.animate(withDuration: 10.0, delay: 0.1, options: [.curveEaseInOut], animations: { 
            
            imageView?.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
            
        }, completion: nil)
        
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        //Parallax Effect
        let percent = Double(self.scrollView.contentOffset.x / self.scrollView.contentSize.width)
        
        for i in 0..<self.slidesViews.count{
            
            
            let slide = self.slidesViews[i]
            let offset = Double(slide.backgroundImage.frame.size.width - UIScreen.main.bounds.size.width) / Double(self.slidesViews.count - 1)
            
            slide.backgroundImage.frame.origin.x = CGFloat(-((percent * offset) + 50))
            
            
        }
        
    }
    
}





































