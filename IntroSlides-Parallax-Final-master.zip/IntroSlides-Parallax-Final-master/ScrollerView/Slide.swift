//
//  Slide.swift
//  ScrollerView
//
//  Created by Jad Habal on 2017-02-04.
//  Copyright © 2017 Jadhabal. All rights reserved.
//

import Foundation
import UIKit


class Slide: UIView {
    
    
    @IBOutlet weak var view:UIView!
    
    @IBOutlet weak var backgroundImage: UIImageView!
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    
    var index:Int?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    func setup(){
        
        backgroundColor = UIColor.clear
        
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        view.translatesAutoresizingMaskIntoConstraints = true
        
        
        addSubview(view)
        
    }
    
   private func loadViewFromNib()->UIView{
        
        let bundle = Bundle(for: type(of:self))
        let nib = UINib(nibName: String.init(describing: type(of:self)), bundle: bundle)
        
        let viewNib = nib.instantiate(withOwner: self, options: nil).first as! UIView
        
        return viewNib
        
    }
    
}

