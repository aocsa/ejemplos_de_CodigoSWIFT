//
//  helper.swift
//  ScrollerView
//
//  Created by Jad Habal on 2017-02-04.
//  Copyright © 2017 Jadhabal. All rights reserved.
//

import Foundation


struct SlideInfoModel{
    
    var title:String
    var description:String
    var imageName:String
}


//Load Plist file and cast the data to SlideInfoModel for latter use
func LoadSlidesPlistFile()->[SlideInfoModel]{
    
    
    guard let path = Bundle.main.path(forResource: "slides_info", ofType: "plist") else{
        print("No Such a file")
        return []
    }
    
    let url = URL.init(fileURLWithPath: path)
    
    let arrayOfInfo = NSArray.init(contentsOf: url) as! [NSDictionary]
    
    let casted = arrayOfInfo.map { (dic:NSDictionary) -> SlideInfoModel in
        
        let title = dic["title"] as! String
        let description = dic["description"] as! String
        let imageName = dic["imageName"] as! String
        
        return SlideInfoModel(title: title, description: description, imageName: imageName)
        
    }
    
    
    
    return casted
    
}
