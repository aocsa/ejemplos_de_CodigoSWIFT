//
//  PageInformation.m
//  SecondScrollView
//
//  Created by yrnunez on 6/02/14.
//  Copyright (c) 2014 yrnunez. All rights reserved.
//

#import "PageInformation.h"

@implementation PageInformation


@end
