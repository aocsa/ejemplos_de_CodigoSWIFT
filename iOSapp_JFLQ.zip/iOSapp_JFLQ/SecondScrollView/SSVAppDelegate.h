//
//  SSVAppDelegate.h
//  SecondScrollView
//
//  Created by yrnunez on 4/02/14.
//  Copyright (c) 2014 yrnunez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SSVAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
