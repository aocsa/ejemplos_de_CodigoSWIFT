//
//  PageInformation.h
//  SecondScrollView
//
//  Created by yrnunez on 6/02/14.
//  Copyright (c) 2014 yrnunez. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PageInformation : NSObject

@property (nonatomic) NSInteger indexInChapter;
@property (nonatomic) NSInteger indexInBook;
@property (nonatomic) NSInteger chapter;

@end
